package Recursos;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;

public class Arista {
	
	private int v1, v2,peso;
	private int xIn,yIn,xFin,yFin;
	private Line2D arista,l1,l2;
	private Color color;
	
	public Arista(int v1, int v2, int peso){
		this.v1 = v1;
		this.v2 = v2;
		this.peso = peso;
		this.color = Color.WHITE;
	}
	
	public void paint(Graphics2D g2d){
		g2d.setColor(color);
		g2d.setStroke(new BasicStroke(2));
		arista = new Line2D.Double(xIn,yIn,xFin,yFin);
		g2d.draw(arista);
		int lenght = 30;
		double angle = angle();
		double x1 = Math.cos(Math.toRadians(angle+45))*lenght;
		double y1 = Math.sin(Math.toRadians(angle+45))*lenght;
		double x2 = Math.cos(Math.toRadians(angle-45))*lenght;
		double y2 = Math.sin(Math.toRadians(angle-45))*lenght;
		double xFin2 = xFin - Math.cos(Math.toRadians(angle))*-(GrafoPanel.r/2);
		double yFin2 = yFin + Math.sin(Math.toRadians(angle))*-(GrafoPanel.r/2);
		l1 = new Line2D.Double(xFin2,yFin2,xFin2+x1,yFin2-y1);
		l2 = new Line2D.Double(xFin2,yFin2,xFin2+x2,yFin2-y2);
		g2d.draw(l1);
		g2d.draw(l2);
	}
	
	public double angle(){
		double dy = yFin-yIn;
		double dx = xFin-xIn;
		double theta = Math.atan2(dy, dx);
		theta *= 180/Math.PI;
		return (180-theta);
	}
	
	public void setColor(Color color){
		this.color = color;
	}
	
	public int getWeight(){
		return this.peso;
	}
	
	public boolean intersectsRect(Rectangle rect){
		return arista.intersects(rect);
	}
	
	public void render(Graphics2D g2d){
		paint(g2d);
	}
	
	public int getV1(){
		return v1;
	}
	
	public int getV2(){
		return v2;
	}
	
	public void setXfin(int xFin){
		this.xFin = xFin;
	}
	
	public void setYfin(int yFin){
		this.yFin = yFin;
	}
	
	public void setXin(int xIn){
		this.xIn = xIn;
	}
	
	public void setYin(int yIn){
		this.yIn = yIn;
	}
}
