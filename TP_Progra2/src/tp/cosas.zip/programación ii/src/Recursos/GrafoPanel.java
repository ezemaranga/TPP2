package Recursos;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JPanel;

import Interfaces.ConjuntoTDA;
import Interfaces.GrafoTDA;

public class GrafoPanel extends JPanel implements MouseListener, MouseMotionListener{
	

	private GrafoTDA grafo;
	public static int r = 50, fontSize = 25;
	private List<Vertice> vertices;
	private List<Arista> aristas;
	private int vertTouched;
	private Rectangle rect;
	
	public void calcularAristas(){
		ConjuntoTDA vert1 = grafo.Vertices();
		ConjuntoTDA vert2;
		int valor1,valor2;
		while(!vert1.ConjuntoVac�o()){
			valor1 = vert1.Elegir();
			vert2 = grafo.Vertices();
			vert1.Sacar(valor1);
			vert2.Sacar(valor1);
			while(!vert2.ConjuntoVac�o()){
				valor2 = vert2.Elegir();
				if(grafo.ExisteArista(valor1, valor2))
					aristas.add(new Arista(valor1,valor2,grafo.PesoArista(valor1, valor2)));
				if(grafo.ExisteArista(valor1, valor1))
					aristas.add(new Arista(valor1,valor1,grafo.PesoArista(valor1, valor1)));
				vert2.Sacar(valor2);
			}
			
		}
	}
	public GrafoPanel(GrafoTDA grafo){
		this.grafo = grafo;
		vertices = new ArrayList<Vertice>();
		aristas = new ArrayList<Arista>();
		rect = new Rectangle(0,0,0,0);
		ConjuntoTDA vert = grafo.Vertices();
		int valor, cant = 0;
		while(!vert.ConjuntoVac�o()){
			valor = vert.Elegir();
			Vertice newVert = new Vertice(valor,cant*r,0,r);
			vertices.add(newVert);
			vert.Sacar(valor);
			cant++;
		}
		calcularAristas();
		Thread t = new Thread(){
			public void run(){
				while(true){
					repaint();
					try {
						Thread.sleep(10);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}
		};
		t.start();
	}
	public boolean verticesIntRect(){
		for(int i=0;i<vertices.size();i++){
			Vertice tmp = vertices.get(i);
			if(tmp.getRectangle().intersects(rect))
				return true;
		}
		return false;
	}
	public void render(Graphics2D g2d){
		for(int i=0;i<aristas.size();i++){
			Arista tmp = aristas.get(i);
			for(int j=0;j<vertices.size();j++){
				Vertice vert = vertices.get(j);
				if(vert.getValor()==tmp.getV1()){
					tmp.setXin(vert.getX()+r/2);
					tmp.setYin(vert.getY()+r/2);
				}
				if(vert.getValor()==tmp.getV2()){
					tmp.setXfin(vert.getX()+r/2);
					tmp.setYfin(vert.getY()+r/2);
				}
			}
			tmp.render(g2d);
			if(tmp.intersectsRect(rect)&&!verticesIntRect()){
				g2d.setColor(Color.YELLOW);
				g2d.fillRoundRect((int)rect.getX(), (int)rect.getY()-r/2, r/2, r/2,15,15);
				FontMetrics metrics = g2d.getFontMetrics();
			    int x = (rect.width - metrics.stringWidth(Integer.toString(tmp.getWeight()))) / 2;
			    int y = ((rect.height - metrics.getHeight()) / 2) - metrics.getAscent();
				g2d.setFont(new Font("Comic Sans",Font.CENTER_BASELINE,10));
				g2d.setColor(Color.BLACK);
				g2d.drawString(Integer.toString(tmp.getWeight()), x+(int)rect.getX()+12, y+(int)rect.getY()+9);
			}
		}
		for(int i=0;i<vertices.size();i++){
			Vertice tmp = vertices.get(i);
			tmp.render(g2d);
		}
		g2d.setColor(Color.YELLOW);
		g2d.setStroke(new BasicStroke(1));
		//g2d.draw(rect);
	}
	public void paint(Graphics g){
		Graphics2D g2d = (Graphics2D) g;
		g2d.setColor(Color.BLACK);
		g2d.fillRect(0,0,super.getWidth(), super.getHeight());
		g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		render(g2d);
	}
	public void mouseDragged(MouseEvent e) {
		int xM = e.getX();
		int yM = e.getY();
		rect = new Rectangle(xM-r/2-r/2,yM-r/2-r/2,r,r);
		for(int i=0;i<vertices.size();i++){
			Vertice tmp = vertices.get(i);		
			if(tmp.getValor() == vertTouched){
				tmp.setX(xM-r);
				tmp.setY(yM-r);
			}
		}
	}
	public void mouseMoved(MouseEvent e) {
		int xM = e.getX();
		int yM = e.getY();
		rect = new Rectangle(xM-r/4,yM-r/2-r/6,r/8,r/8);
		for(int i=0;i<vertices.size();i++){
			Vertice tmp = vertices.get(i);	
			if(tmp.getRectangle().intersects(rect)){
				vertTouched = tmp.getValor();
				tmp.setColor(new Color(250,0,0));
			}else{
				tmp.setColor(Color.BLACK);
			}
		}
		for(int i=0;i<aristas.size();i++){
			Arista tmp = aristas.get(i);
			if(tmp.intersectsRect(rect)&&!verticesIntRect()){
				tmp.setColor(Color.YELLOW);
			}else{
				tmp.setColor(Color.WHITE);
			}
		}
	}
	public void mouseClicked(MouseEvent e) {}
	public void mouseEntered(MouseEvent e) {}
	public void mouseExited(MouseEvent e) {}
	public void mousePressed(MouseEvent e) {
		int xM = e.getX();
		int yM = e.getY();
		for(int i=0;i<vertices.size();i++){
			Vertice tmp = vertices.get(i);		
			if(tmp.getValor() == vertTouched){
				tmp.setX(xM-r);
				tmp.setY(yM-r);
			}
		}
	}
	public void mouseReleased(MouseEvent e) {}
	
}
