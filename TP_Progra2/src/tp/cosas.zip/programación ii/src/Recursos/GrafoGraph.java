package Recursos;

import javax.swing.JFrame;

import Interfaces.GrafoTDA;

public class GrafoGraph {
	
	public static final int WIDTH = 800;
	public static final int HEIGHT = 600;
	
	public GrafoGraph(GrafoTDA grafo, String title){
		JFrame f = new JFrame(title);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		GrafoPanel p = new GrafoPanel(grafo);
		f.add(p);
		f.addMouseListener(p);
		f.addMouseMotionListener(p);
		f.setSize(800, 600);
		f.setLocationRelativeTo(null);
		f.setVisible(true);
	}
}
