package Recursos;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.geom.Ellipse2D;
import java.util.Random;

public class Vertice{
	
	private int x,y,r,valor;
	private Color color;
	
	public Vertice(int valor, int x, int y, int r){
		this.valor = valor;
		this.x = x;
		this.y = y;
		this.r = r;
		Random rand = new Random();
		this.color = Color.BLACK;
		//this.color = new Color(rand.nextInt(90)+100,rand.nextInt(90)+10,rand.nextInt(90)+100);
	}
	
	public void setColor(Color color){
		this.color = color;
	}
	
	public void render(Graphics2D g2d){
		paint(g2d);
	}
	
	public void paint(Graphics2D g2d){
		g2d.setColor(color);
		Ellipse2D n = new Ellipse2D.Double(x,y,r,r);
		g2d.fill(n);
		g2d.setColor(Color.WHITE);
		Ellipse2D c = new Ellipse2D.Double(x,y,r,r);
		g2d.setStroke(new BasicStroke(4));
		g2d.draw(c);
		g2d.setFont(new Font("Comic Sans",Font.CENTER_BASELINE,20));
		g2d.drawString(Integer.toString(valor),x+r/2-r/6,y+r/2+r/6);
	}
	
	public void setValor(int valor){
		this.valor = valor;
	}
	
	public void setX(int x){
		this.x = x;
	}
	
	public void setY(int y){
		this.y = y;
	}
	
	public Rectangle getRectangle(){
		Rectangle rect = new Rectangle(x,y,r,r);
		return rect;
	}
	
	public int getValor(){
		return this.valor;
	}
	
	public int getX(){
		return this.x;
	}
	
	public int getY(){
		return this.y;
	}
}
