package Recursos;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.geom.Ellipse2D;

import javax.swing.JPanel;

import Interfaces.ABBTDA;

public class GraphPanel extends JPanel implements KeyListener{
	
	private static final long serialVersionUID = 1L;
	private ABBTDA aOrig;
	public static int r=40;
	private int xdesp,ydesp=3*r,dx=35,prof,fontSize=15;

	public void paint(Graphics g){
		Graphics2D g2d = (Graphics2D)g;
		xdesp = dx*prof*prof;
		g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		g2d.setStroke(new BasicStroke(2));
		g2d.setColor(new Color(0,0,0));
		g2d.fillRect(0, 0, getWidth(), getHeight());
		dibujarArbol(aOrig, getWidth()/2 + ABBGraph.f.getWidth()/2,10,g2d);
	}

	public static int prof(ABBTDA a) {
	   if (a.ABBVac�o()){
		    return -1;
	   }else{
		    int izq = prof(a.HijoIzq())+1;
		    int der = prof(a.HijoDer())+1;
		    if(izq>der)
		    	return izq;
		    else
		    	return der;
	   }
	 }
	
	public void dibujarNodo(int x, int y, int info, int hijos, Graphics2D g2d){
		int rdesp = r/2;
		g2d.setColor(new Color(255,255,255));
		if(hijos==2){
			g2d.drawLine(x+rdesp, y+rdesp, x-xdesp+rdesp, y+ydesp+rdesp);
			g2d.drawLine(x+rdesp, y+rdesp, x+xdesp+rdesp, y+ydesp+rdesp);
		}else if(hijos==0)
			g2d.drawLine(x+rdesp, y+rdesp, x-xdesp+rdesp, y+ydesp+rdesp);
		else if(hijos==1)
			g2d.drawLine(x+rdesp, y+rdesp, x+xdesp+rdesp, y+ydesp+rdesp);
		g2d.setColor(new Color(100,100,100));
		Ellipse2D e = new Ellipse2D.Double(x, y, r, r);
		g2d.fill(e);
		g2d.setColor(new Color(255,255,255));
		g2d.setFont(new Font("Arial",Font.CENTER_BASELINE,fontSize));
		g2d.drawString(Integer.toString(info),x+r/5,y+rdesp+r/6);
		g2d.draw(e);
	}
	
	public void dibujarArbol(ABBTDA a, int x, int y, Graphics2D g2d){
		int hijos=-1;
		if (!a.ABBVac�o()){
			if(!a.HijoIzq().ABBVac�o()&&!a.HijoDer().ABBVac�o())
				hijos=2;
			else if(!a.HijoIzq().ABBVac�o()&&a.HijoDer().ABBVac�o())
				hijos=0;
			else if(a.HijoIzq().ABBVac�o()&&!a.HijoDer().ABBVac�o())
				hijos=1;
			int xdespAnt = xdesp;
			xdesp = xdesp/2;
			dibujarNodo(x,y,a.Ra�z(),hijos,g2d);
			dibujarArbol(a.HijoIzq(),x-xdesp,y+ydesp,g2d);
			xdesp=xdespAnt/2;
			dibujarArbol(a.HijoDer(),x+xdesp,y+ydesp,g2d);
		}
	}	
	
	public GraphPanel(ABBTDA a){
		this.aOrig = a;
		prof = prof(aOrig);
		Thread update = new Thread(){
			public void run(){
				while(true){
					repaint();
					try {
						Thread.sleep(10);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}
		};
		update.start();
	}
	
    public void keyPressed(KeyEvent e) {
		if(e.getKeyCode()==KeyEvent.VK_DOWN){
			dx++;
			ydesp++;
		}else if(e.getKeyCode()==KeyEvent.VK_UP){
			if(dx-1>3&&ydesp-1>r){
				dx--;
				ydesp--;
			}
		}
	}
    
	public void keyReleased(KeyEvent arg0) {}
	public void keyTyped(KeyEvent arg0) {}
}




