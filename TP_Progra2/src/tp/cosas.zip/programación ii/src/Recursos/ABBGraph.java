package Recursos;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.KeyListener;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import Interfaces.ABBTDA;

public class ABBGraph extends JPanel{
	
	private static final long serialVersionUID = 1L;
	public static JFrame f;
	
	public void plot(ABBTDA a, String name){
		f = new JFrame(name);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setResizable(true);
		f.setLocationRelativeTo(null);
		JPanel p = new GraphPanel(a);
		p.setPreferredSize(new Dimension(getMaximumSize().width*2,getMaximumSize().height));
		f.add(p);
		f.addKeyListener((KeyListener) p);
		JScrollPane scroll = new JScrollPane(p);
		f.getContentPane().add(scroll, BorderLayout.CENTER);
		f.setSize(960, 900);
		f.setLocationRelativeTo(null);
		f.setExtendedState(f.getExtendedState()|JFrame.MAXIMIZED_BOTH);
		f.setLocationByPlatform(true);
		f.setVisible(true);
		scroll.getHorizontalScrollBar().setValue(p.getWidth()/2 + GraphPanel.r);
	}
}























