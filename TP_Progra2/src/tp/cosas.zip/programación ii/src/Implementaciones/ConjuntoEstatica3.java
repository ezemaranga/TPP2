package Implementaciones;

import Interfaces.ConjuntoTDA;

public class ConjuntoEstatica3 implements ConjuntoTDA {
	/* Esta implementacion guardar� un "1" en la posici�n del vector correspondiente al n�mero que represente, si el n�mero no esta
	presente se guardar� un 0 */
	// DATOS
	int[]C;
	final int MAX=100;
	// M�TODOS
	public void InicializarConjunto() { // Costos: Lineal (Temporal) - Lineal (Espacial)
		C = new int[MAX];
		for(int i=0; i<MAX; i++)
			C[i]=0;
	}
	public boolean ConjuntoVac�o() { // Costos: Lineal (Temporal) - Constante (Espacial)
		int i=0;
		while (i<MAX && C[i]==0)
			i++;
		return i==MAX;
	}
	public void Agregar(int e) { // Costos: Constante (Temporal) - Cero (Espacial)
		C[e]=1;
	}
	public int Elegir() { // Costos: Lineal (Temporal) - Constante (Espacial)
		int i=0;
		while(C[i]!=1)
			i++;
		return i;
	}
	public void Sacar(int e) { // Costos: Constante (Temporal) - Cero (Espacial)
		C[e]=0;
	}
	public boolean Pertenece(int e) { // Costos: Constante (Temporal) - Cero (Espacial)
		return (C[e]==1);
	}
}
