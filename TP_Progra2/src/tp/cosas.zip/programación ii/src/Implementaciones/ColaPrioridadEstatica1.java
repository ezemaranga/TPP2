package Implementaciones;

import Interfaces.ColaPrioridadTDA;

public class ColaPrioridadEstatica1 implements ColaPrioridadTDA {
	// DATOS
	int[] elementos;
	int[] prioridades;
	int indice;
	// M�TODOS
	public void InicializarCola() { // Costos: Constante (Temporal) - Constante (Espacial)
		indice = 0;
		elementos = new int[100];
		prioridades = new int[100];
	}
	public boolean ColaVac�a() { // Costos: Constante (Temporal) - Cero (Espacial)
		return indice==0;
	}
	public int Primero() { // Costos: Constante (Temporal) - Cero (Espacial)
		return elementos[indice-1];
	}
	public void AcolarPrioridad(int x, int prioridad) { // Costos: Lineal (Temporal) - Constante (Espacial)
		// desplaza a derecha los elementos de la cola mientras
		// estos tengan mayor o igual prioridad que la de x
		int j = indice;
		for ( ; j>0 && prioridades[j -1] >= prioridad; j--){
			elementos[j] = elementos[j -1];
			prioridades[j] = prioridades[j -1];
		}
		elementos[j] = x;
		prioridades[j] = prioridad;
		indice++;
	}
	public void Desacolar() { // Costos: Constante (Temporal) - Cero (Espacial)
		indice--;
	}
	public int Prioridad() { // Costos: Constante (Temporal) - Cero (Espacial)
		return prioridades[indice-1];
	}
}