package Implementaciones;

import Interfaces.ColaTDA;

public class ColaEstatica1 implements ColaTDA {
	/* En esta implementacion de guardan todos los datos nuevos al final, por lo tanto para eliminar un valor este siempre ser�
	el primero (deber� reordenarse el arreglo) */ 
	// DATOS
	int[] A;
	int cant;
	final int MAX=100;
	// M�TODOS
	public void InicializarCola() { // Costos: Constante (Temporal) - Lineal (Espacial)
		A = new int[MAX];
		cant=0;
	}
	public boolean ColaVac�a() { // Costos: Constante (Temporal) - Cero (Espacial)
		return cant==0;
	}
	public int Primero() { // Costos: Constante (Temporal) - Cero (Espacial)
		return A[0];
	}
	public void Acolar(int x) { // Costos: Constante (Temporal) - Cero (Espacial)
		A[cant]=x;
		cant++;
	}
	public void Desacolar() { // Costos: Lineal (Temporal) - Constante (Espacial)
		for(int i=0; i<cant-1; i++)
			A[i] = A[i+1];
		cant--;
	}
}