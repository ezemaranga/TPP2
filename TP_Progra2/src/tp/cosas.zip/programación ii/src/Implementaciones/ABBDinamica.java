package Implementaciones;

import Interfaces.ABBTDA;

public class ABBDinamica implements ABBTDA {
	// DATOS
	class NodoABB{
		int info;
		ABBTDA hijoIzq;
		ABBTDA hijoDer;
	}
	NodoABB raiz;
	// M�TODOS
	public void InicializarABB() { // Costos: Constante (Temporal) - Cero (Espacial)
		raiz = null;
	}
	public boolean ABBVac�o() { // Costos: Constante (Temporal) - Cero (Espacial)
		return raiz==null;
	}
	public void AgregarElem(int x) { // Costos: Constante (Temporal) - Constante (Espacial)
		if(raiz==null){
			raiz = new NodoABB();
			raiz.info = x;
			raiz.hijoIzq = new ABBDinamica();
			raiz.hijoIzq.InicializarABB();
			raiz.hijoDer = new ABBDinamica();
			raiz.hijoDer.InicializarABB();
		}
		else if(raiz.info>x)
			raiz.hijoIzq.AgregarElem(x);
		else if(raiz.info<x)
			raiz.hijoDer.AgregarElem(x);
	}
	public void EliminarElem(int x) { // Costos: Constante (Temporal) - Cero (Espacial)
		if(raiz!=null){
			if(raiz.info==x && raiz.hijoIzq.ABBVac�o() && raiz.hijoDer.ABBVac�o())
				raiz=null;
			else if(raiz.info==x && !raiz.hijoIzq.ABBVac�o()){
				raiz.info = this.mayor(raiz.hijoIzq);
				raiz.hijoIzq.EliminarElem(raiz.info);
			}
			else if(raiz.info==x && raiz.hijoIzq.ABBVac�o()){
				raiz.info = this.menor(raiz.hijoDer);
				raiz.hijoDer.EliminarElem(raiz.info);
			}
			else if(raiz.info<x){
				raiz.hijoDer.EliminarElem(x);
			}
			else{
				raiz.hijoIzq.EliminarElem(x);
			}
		}
	}
	public int Ra�z() { // Costos: Constante (Temporal) - Cero (Espacial)
		return raiz.info;
	}
	public ABBTDA HijoIzq() { // Costos: Constante (Temporal) - Cero (Espacial)
		return raiz.hijoIzq;
	}
	public ABBTDA HijoDer() { // Costos: Constante (Temporal) - Cero (Espacial)
		return raiz.hijoDer;
	}
	// M�TODOS AUXILIARES
	private int mayor( ABBTDA a){
		if(a.HijoDer().ABBVac�o())
			return a.Ra�z();
		else
			return mayor(a. HijoDer());
	}
	private int menor( ABBTDA a){
		if(a.HijoIzq().ABBVac�o())
			return a.Ra�z();
		else
			return menor(a. HijoIzq());
	}
}