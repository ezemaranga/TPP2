package Implementaciones;

import Interfaces.ColaTDA;

public class ColaDin�mica2 implements ColaTDA {
	// Se utilizan listas dobles enlazadas
	// DATOS
	class nodo{
		int Info;
		nodo Sig;
	}
	nodo P;
	nodo U;
	// M�TODOS
	public void InicializarCola() { // Costos: Constante (Temporal) - Cero (Espacial)
		P = null;
		U = null;
	}
	public boolean ColaVac�a() { // Costos: Constante (Temporal) - Cero (Espacial)
		return P==null;
	}
	public int Primero() { // Costos: Constante (Temporal) - Cero (Espacial)
		return P.Info;
	}
	public void Acolar(int x) { // Costos: Constante (Temporal) - Constante (Espacial)
		nodo Nuevo = new nodo();
		Nuevo.Info = x;
		Nuevo.Sig = null;
		if(P!=null)
			U.Sig = Nuevo;
		else
			P = Nuevo;
		U = Nuevo;
	}
	public void Desacolar() { // Costos: Constante (Temporal) - Cero (Espacial)
		P = P.Sig;
		if(P==null)
			U=null;
	}
}
