package Implementaciones;

import Interfaces.ColaTDA;

public class ColaDin�mica implements ColaTDA {
	// Se utilizan listas simples enlazadas
	// DATOS
	class nodo{
		int Info;
		nodo Sig;
	}
	nodo P;
	// M�TODOS
	public void InicializarCola() { // Costos: Constante (Temporal) - Cero (Espacial)
		P=null;
	}
	public boolean ColaVac�a() { // Costos: Constante (Temporal) - Cero (Espacial)
		return P==null;
	}
	public int Primero() { // Costos: Constante (Temporal) - Cero (Espacial)
		return P.Info;
	}
	public void Acolar(int x) { // Costos: Lineal (Temporal) - Constante (Espacial)
		nodo Nuevo = new nodo();
		Nuevo.Info = x;
		Nuevo.Sig = null;
		if(P==null){ // Cola Vac�a
			P = Nuevo;
		}else{
			nodo Aux = P;
			while(Aux.Sig != null)
				Aux = Aux.Sig;
			Aux.Sig = Nuevo;
		}
	}
	public void Desacolar() { // Costos: Constante (Temporal) - Cero (Espacial)
		P = P.Sig;
	}
}
