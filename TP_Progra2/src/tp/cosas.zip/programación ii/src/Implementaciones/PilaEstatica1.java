package Implementaciones;

import Interfaces.PilaTDA;

public class PilaEstatica1 implements PilaTDA {
	// DATOS
	int[] A;
	int cant;
	final int MAX=100;
	// M�TODOS
	public void InicializarPila() { // Costos: Constante (Temporal) - Lineal (Espacial)
		A = new int[MAX];
		cant=0;
	}
	public boolean PilaVac�a() { // Costos: Constante (Temporal) - Cero (Espacial)
		return cant==0;
	}
	public int Tope() { // Costos: Constante (Temporal) - Cero (Espacial)
		return A[cant-1];
	}
	public void Apilar(int x) { // Costos: Constante (Temporal) - Cero (Espacial)
		A[cant]=x;
		cant++;
	}
	public void Desapilar() { // Costos: Constante (Temporal) - Cero (Espacial)
		cant--;
	}
}