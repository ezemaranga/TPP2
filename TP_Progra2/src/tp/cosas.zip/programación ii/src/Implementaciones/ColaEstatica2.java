package Implementaciones;

import Interfaces.ColaTDA;

public class ColaEstatica2 implements ColaTDA {
	/* En esta implementaci�n se guardan todos los datos nuevos a la cola al principio del arreglo, por lo tanto para acolar uno nuevo deber�
	reordenarse todo el arreglo */
	// DATOS
	int[] A;
	int indice;
	final int MAX=100;
	// M�TODOS
	public void InicializarCola() { // Costos: Constante (Temporal) - Lineal (Espacial)
		A = new int[MAX];
		indice=0;
	}
	public boolean ColaVac�a() { // Costos: Constante (Temporal) - Cero (Espacial)
		return indice==0;
	}
	public int Primero() { // Costos: Constante (Temporal) - Cero (Espacial)
		return A[indice-1];
	}
	public void Acolar(int x) { // Costos: Constante (Temporal) - Cero (Espacial)
		for(int i= indice-1; i>=0; i--)
			A[i+1] = A[i];
		A[0] = x;
		indice++;
	}
	public void Desacolar() { // Costos: Lineal (Temporal) - Constante (Espacial)
		indice--;
	}
}