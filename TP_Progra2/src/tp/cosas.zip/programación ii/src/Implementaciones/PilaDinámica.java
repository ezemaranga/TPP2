package Implementaciones;

import Interfaces.PilaTDA;

public class PilaDin�mica implements PilaTDA {
	// DATOS
	class nodo{
		int info;
		nodo sig;
	}
	nodo L;
	// M�TODOS
	public void InicializarPila() { // Costos: Constante (Temporal) - Cero (Espacial)
		L=null;
	}
	public boolean PilaVac�a() { // Costos: Constante (Temporal) - Cero (Espacial)
		return L==null;
	}
	public int Tope() { // Costos: Constante (Temporal) - Cero (Espacial)
		return L.info;
	}
	public void Apilar(int x) { // Costos: Constante (Temporal) - Constante (Espacial)
		nodo nuevo = new nodo();
		nuevo.info = x;
		nuevo.sig = L;
		L = nuevo;
	}
	public void Desapilar() { // Costos: Constante (Temporal) - Cero (Espacial)
		L = L.sig;
	}
}
