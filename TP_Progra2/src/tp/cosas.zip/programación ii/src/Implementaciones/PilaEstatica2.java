package Implementaciones;

import Interfaces.PilaTDA;

public class PilaEstatica2 implements PilaTDA {
	// DATOS
	int[] A;
	int indice; // Cantidad de elementos en la pila
	final int MAX=100;
	// M�TODOS
	public void InicializarPila() { // Costos: Constante (Temporal) - Lineal (Espacial)
		A = new int[MAX];
		indice=0;
	}
	public boolean PilaVac�a() { // Costos: Constante (Temporal) - Cero (Espacial)
		return indice==0;
	}
	public int Tope() { // Costos: Constante (Temporal) - Cero (Espacial)
		return A[0];
	}
	public void Apilar(int x) { // Costos: Constante (Temporal) - Cero (Espacial)
		for(int i = indice-1; i>=0; i--)
			A[i+1] = A[i];
		A[0] = x;
		indice++;
	}
	public void Desapilar() { // Costos: Constante (Temporal) - Cero (Espacial)
		for(int i=0; i<indice; i++)
			A[i] = A[i+1];
		indice--;
	}
}