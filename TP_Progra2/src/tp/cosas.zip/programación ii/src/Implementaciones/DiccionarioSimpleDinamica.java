package Implementaciones;

import Interfaces.ConjuntoTDA;
import Interfaces.DiccionarioSimpleTDA;

public class DiccionarioSimpleDinamica implements DiccionarioSimpleTDA {
	// DATOS 
	class NodoClave{
		int clave;
		int valor;
		NodoClave sigClave;
	}
	NodoClave origen;
	// M�TODOS
	public void InicializarDiccionario() { // Costos: Constante (Temporal) - Cero (Espacial)
		origen = null;
	}
	public void Agregar(int clave, int valor) { // Costos: Constante (Temporal) - Lineal (Espacial)
		NodoClave nc = Clave2NodoClave(clave);
		if(nc == null){
			nc = new NodoClave();
			nc.clave = clave;
			nc.sigClave = origen;
			origen = nc;
		}
		nc.valor = valor;
	}
	private NodoClave Clave2NodoClave(int clave){ // Costos: Lineal (Temporal) - Constante (Espacial)
		NodoClave aux = origen;
		while(aux!=null && aux.clave!=clave){
			aux = aux.sigClave;
		}
		return aux;
	}
	public void Eliminar(int clave) { // Costos: Lineal (Temporal) - Constante (Espacial)
		if(origen != null){
			if(origen.clave == clave){
				origen = origen.sigClave;
			}else{
				NodoClave aux = origen;
				while(aux.sigClave!=null && aux.sigClave.clave!=clave){
				aux = aux. sigClave;
				}
				if(aux.sigClave != null){
					aux.sigClave = aux.sigClave.sigClave;
				}
			}
		}
	}
	public int Recuperar(int clave) { // Costos: Constante (Temporal) - Lineal (Espacial)
		NodoClave n = Clave2NodoClave(clave);
		return n. valor;
	}
	public ConjuntoTDA Claves() { // Costos: Lineal (Temporal) - Constante (Espacial)
		ConjuntoTDA c = new ConjuntoEstatica1();
		c.InicializarConjunto();
		NodoClave aux = origen;
		while(aux != null){
			c.Agregar(aux .clave);
			aux = aux.sigClave;
		}
		return c;
	}
}
