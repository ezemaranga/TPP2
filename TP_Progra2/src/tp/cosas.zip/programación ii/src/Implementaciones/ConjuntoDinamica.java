package Implementaciones;

import Interfaces.ConjuntoTDA;

public class ConjuntoDinamica implements ConjuntoTDA {
	// DATOS
	class nodo{
		int Info;
		nodo Sig;
	}
	nodo C;
	// M�TODOS
	public void InicializarConjunto() { // Costos: Constante (Temporal) - Cero (Espacial)
		C=null;
	}
	public boolean ConjuntoVac�o() { // Costos: Constante (Temporal) - Cero (Espacial)
		return C==null;
	}
	public void Agregar(int e) { // Costos: Constante (Temporal) - Constante (Espacial)
		if(!this.Pertenece(e)){
			nodo Nuevo = new nodo();
			Nuevo.Info = e;
			Nuevo.Sig = C;
			C = Nuevo;
		}
	}
	public int Elegir() { // Costos: Constante (Temporal) - Cero (Espacial)
		return C.Info;
	}
	public void Sacar(int e) { // Costos: Lineal (Temporal) - Constante (Espacial)
		nodo Aux = C;
		while(Aux!=null && Aux.Info!=e)
			Aux = Aux.Sig;
		if(Aux!=null){
			Aux.Info = C.Info;
			C = C.Sig;
		}
	}
	public boolean Pertenece(int e) { // Costos: Lineal (Temporal) - Constante (Espacial)
		nodo Aux = C;
		while(Aux!=null && Aux.Info!=e)
			Aux = Aux.Sig;
		return Aux!=null;
	}
}