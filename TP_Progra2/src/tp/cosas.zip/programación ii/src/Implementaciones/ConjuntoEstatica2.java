package Implementaciones;

import java.util.Random;

import Interfaces.ConjuntoTDA;

public class ConjuntoEstatica2 implements ConjuntoTDA {
	/* Variaci�n de la implementacion "ConjuntoEstatica1" con Elegir con n�meros random */
	// DATOS
	int[] C;
	int cant;
	final int MAX = 100;
	// M�TODOS
	public void InicializarConjunto() { // Costos: Constante (Temporal) - Lineal (Espacial)
		C = new int[MAX];
		cant=0;
	}
	public boolean ConjuntoVac�o() { // Costos: Constante (Temporal) - Cero (Espacial)
		return cant==0;
	}
	public void Agregar(int e) { // Costos: Constante (Temporal) - Cero (Espacial)
		if (!this.Pertenece(e)){
			C[cant] = e;
			cant++;
		}
	}
	public int Elegir() { // Costos: Constante (Temporal) - Constante (Espacial)
		Random gen = new Random();
		int indice = gen.nextInt(cant);
		return C[indice];
	}
	public void Sacar(int e) { // Costos: Lineal (Temporal) - Constante (Espacial)
		int i=0;
		while(i<cant && C[i]!=e)
			i++;
		if(i<cant){
			C[i] = C[cant-1];
			cant--;
		}
	}
	public boolean Pertenece(int e) { // Costos: Lineal (Temporal) - Constante (Espacial)
		int i=0;
		while(i<cant && C[i]!=e)
			i++;
		return i<cant;
	}
}