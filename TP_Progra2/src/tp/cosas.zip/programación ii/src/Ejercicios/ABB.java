package Ejercicios;

import Interfaces.ABBTDA;
import Interfaces.ConjuntoTDA;
import Interfaces.PilaTDA;
import Implementaciones.ABBDinamica;
import Implementaciones.ConjuntoEstatica1;
import Implementaciones.PilaEstatica1;
import Recursos.ABBGraph;

public class ABB {
	
	// TP4 - 3.a - Dado un elemento, determinar si esta o no en un ABB
	static boolean estaElem(ABBTDA a, int x){
		if(a.ABBVac�o()){
			return false;
		}else{
			if(a.Ra�z()==x)
				return true;
			else{
				if(x>a.Ra�z()) // Hijo Derecho
					return estaElem(a.HijoDer(),x);
				else // Hijo Izquierdo
					return estaElem(a.HijoIzq(),x);
			}
		}	
	}
	
	// TP4 - 3.b - Dado un elemento, determinar si es una hoja de un ABB*/
	static boolean esHoja(ABBTDA A, int x){
		if(A.ABBVac�o())
			return false;
		else{
			if(A.Ra�z()==x){
				if(A.HijoDer().ABBVac�o() && A.HijoIzq().ABBVac�o())
					return true;
				else
					return false;
			}else{
				if(x>A.Ra�z())
					return esHoja(A.HijoDer(),x);
				else
					return esHoja(A.HijoIzq(),x);
			}
		}
	}	
	
	// TP4 - 3.c - Dado un elemento, calcular su profundidad en el ABB
	static int profundidad(ABBTDA A, int x){
		if(A.Ra�z()==x)
			return 0;
		else{
			if(x>A.Ra�z())
				return 1 + profundidad(A.HijoDer(),x);
			else
				return 1 + profundidad(A.HijoIzq(),x);
		}
	}
	
	// TP4 - 3.d - Obtener el valor del menor elemento de un ABB
	static int menorElemento(ABBTDA A){
		if(A.ABBVac�o())
			return 0;
		else{
			if(A.HijoIzq().ABBVac�o())
				return A.Ra�z();
			else
				return menorElemento(A.HijoIzq());
		}
	}
	
	// TP4 - 3.e - Calcular la cantidad de elementos que contiene un ABB
	static int cantidadElementos(ABBTDA A){
		if(A.ABBVac�o())
			return 0;
		else{
			return 1 + cantidadElementos(A.HijoDer()) + cantidadElementos(A.HijoIzq());
		}
	}
	
	// TP4 - 3.f - Calcular la suma de los elementos que contiene un ABB
	static int sumaElementos(ABBTDA A){
		if(A.ABBVac�o())
			return 0;
		else{
			return A.Ra�z() + sumaElementos(A.HijoDer()) + sumaElementos(A.HijoIzq());		}
	}
	
	// TP4 - 3.g - Calcular la cantidad de hojas de un ABB
	static int cantidadHojas(ABBTDA A){
		if(A.ABBVac�o())
			return 0;
		else{
			if(A.HijoDer().ABBVac�o() && A.HijoIzq().ABBVac�o()) // Es Hoja
				return 1;
			else
				return cantidadHojas(A.HijoDer()) + cantidadHojas(A.HijoIzq());
		}
	}
	
	// TP4 - 3.h - Calcular la altura de un ABB
	static int alturaABB(ABBTDA A){
		if(A.ABBVac�o())
			return -1;
		else{
			if(alturaABB(A.HijoIzq())>alturaABB(A.HijoDer()))
				return 1 + alturaABB(A.HijoIzq());
			else
				return 1 + alturaABB(A.HijoDer());
		}
	}
	
	// TP4 - 3.i - Comprobar si dos ABBs tienen la misma forma
	static boolean igualForma(ABBTDA a,ABBTDA b){
		PilaTDA pa = new PilaEstatica1();
		pa.InicializarPila();
		PilaTDA pb = new PilaEstatica1();
		pb.InicializarPila();
		formaDeArbol(a,pa);
		formaDeArbol(b,pb);
		while(!pa.PilaVac�a()&&!pb.PilaVac�a()){
			if(pa.Tope()!=pb.Tope())
				return false;
			if(!pb.PilaVac�a())
				pb.Desapilar();
			pa.Desapilar();
		}
		return pa.PilaVac�a()&&pb.PilaVac�a();
	}
	static void formaDeArbol(ABBTDA a, PilaTDA p1){
		if(!a.ABBVac�o()){
			formaDeArbol(a.HijoIzq(),p1);
			p1.Apilar(0);
			formaDeArbol(a.HijoDer(),p1);
			p1.Apilar(1);
		}
	}
	
	// TP4 - 3.j - Comprobar si dos ABBs son iguales
	static boolean identicosABB(ABBTDA A, ABBTDA B){
		if(A.ABBVac�o() && B.ABBVac�o())
			return true;
		else
			return !A.ABBVac�o() && !B.ABBVac�o() && A.Ra�z()==B.Ra�z() && identicosABB(A.HijoIzq(), B.HijoIzq()) && identicosABB(A.HijoDer(), B.HijoDer());
	}
	
	// TP4 - 3.k - Contar la cantidad de elementos que est�n en un cierto nivel N
	static int cantidadElementosNivel(ABBTDA A, int n){
		if(A.ABBVac�o())
			return 0;
		else{
			if(n==0)
				return 1;
			else
				return cantidadElementosNivel(A.HijoDer(), n-1) + cantidadElementosNivel(A.HijoIzq(), n-1);
		}
	}
	
	// TP4 - 3.l.i - Mostrar por pantalla todos los elementos que contiene un ABB - In-Orden
	static void inOrden(ABBTDA A){
		if(!A.ABBVac�o()){
			inOrden(A.HijoIzq());
			System.out.print(" " + A.Ra�z());
			inOrden(A.HijoDer());
		}
	}
	
	// TP4 - 3.l.ii - Mostrar por pantalla todos los elementos que contiene un ABB - Pre-Orden
	static void preOrden(ABBTDA A){
		if(!A.ABBVac�o()){
			System.out.print(" " + A.Ra�z());
			preOrden(A.HijoIzq());
			preOrden(A.HijoDer());
		}
	}
	
	// TP4 - 3.l.iii - Mostrar por pantalla todos los elementos que contiene un ABB - Post-Orden
	static void postOrden(ABBTDA A){
		if(!A.ABBVac�o()){
			postOrden(A.HijoDer());
			System.out.print(" " + A.Ra�z());
			postOrden(A.HijoIzq());
			
		}
	}
	
	// TP4 - 3.m - Dado un valor k, arme un conjunto con todos los elementos del ABB que son mayores que k
	static ConjuntoTDA ConjuntoMayoresK(ABBTDA A, int k){
		ConjuntoTDA C = new ConjuntoEstatica1();
		C.InicializarConjunto();
		ConjuntoMayoresAux(A,k,C);
		return C;
	}
	static void ConjuntoMayoresAux(ABBTDA A, int k, ConjuntoTDA C){
		if(!A.ABBVac�o()){
			if(A.Ra�z()>k){
				C.Agregar(A.Ra�z());
				ConjuntoMayoresAux(A.HijoIzq(),k,C);
			}
			ConjuntoMayoresAux(A.HijoDer(),k,C);
		}
	}
	
	/* TP4 - 3.n - Dado un elemento de valor v (que est� presente en el ABB), obtener el elemento del �rbol que 
	es inmediatamente anterior (en valor)*/
	static int valorAnterior(ABBTDA A, int v){
		int cond=v;
		ABBTDA aux = A;
		while(!aux.ABBVac�o()){
			if(aux.Ra�z()<v){
				cond = aux.Ra�z();
				aux = aux.HijoDer();
			}else
				aux = aux.HijoIzq();
		}
		return cond;
	}
	
	// Dado un ABBTDA A, escribir un m�todo externo que permita determinar cu�ntos elementos de A tienen un solo hijo
	static int elementosSinHermano(ABBTDA A){
		if(A.ABBVac�o())
			return 0;
		else{
			if ((A.HijoDer().ABBVac�o() && !A.HijoIzq().ABBVac�o()) || (!A.HijoDer().ABBVac�o() && A.HijoIzq().ABBVac�o()))
				return 1 + elementosSinHermano(A.HijoDer()) + elementosSinHermano(A.HijoIzq());
			else
				return elementosSinHermano(A.HijoDer()) + elementosSinHermano(A.HijoIzq());
		}
	}
	
	// Dado un ABBTDA A, calcular cuantos elementos tienen 2 hijos
	static int elementosDosHijos(ABBTDA A){
		if(A.ABBVac�o())
			return 0;
		else{
			if(A.HijoIzq().ABBVac�o() || A.HijoDer().ABBVac�o())
				return elementosDosHijos(A.HijoDer()) + elementosDosHijos(A.HijoIzq());
			else
				return 1 + elementosDosHijos(A.HijoDer()) + elementosDosHijos(A.HijoIzq());
		}
	}
	
	// Dado un ABBTDA A y un entero x, escribir un m�todo externo que permita determinar cu�ntos elementos de A son mayores que x
	static int cantidadElemMayoresX(ABBTDA A, int x){
		if(A.ABBVac�o())
			return 0;
		else{
			if(A.Ra�z()>x)
				return 1 + cantidadElemMayoresX(A.HijoIzq(),x) + cantidadElemMayoresX(A.HijoDer(),x);
			else
				return cantidadElemMayoresX(A.HijoIzq(),x) + cantidadElemMayoresX(A.HijoDer(),x);
		}
	}
	
	// Dado un ABBTDA A (no vac�o), determinar el menor valor de las hojas de A
	static int menorHojas(ABBTDA A){
		if(A.HijoIzq().ABBVac�o() && A.HijoDer().ABBVac�o())
			return A.Ra�z();
		else if(!A.HijoIzq().ABBVac�o() && A.HijoDer().ABBVac�o()){ // Es Hoja
			int menorIzq = menorHojas(A.HijoIzq());
			int menorDer = menorHojas(A.HijoDer());
			return menorIzq<menorDer?menorIzq:menorDer;
		}else
			if(!A.HijoIzq().ABBVac�o())
				return menorHoja(A.HijoIzq());
			else
				return menorHoja(A.HijoDer());
	}
	
	// Dado un ABBTDA y un entero N, determinar cuantos elementos de A estan en un nivel menor o igual a N
	static int CantidadElementosMenorIgualN(ABBTDA A, int n){
		if (A.ABBVac�o()){
			return 0;
		}else{
			if(n==0){
				return 1;
			}else{
				return 1 + CantidadElementosMenorIgualN(A.HijoIzq(),n-1) + CantidadElementosMenorIgualN(A.HijoDer(),n-1);
			}
		}
	}
	
	// Dado un ABB A y un valor X (que se encuentra en A), determinar si A tiene alg�n elemento por debajo de X; es decir, tenga un nivel m�s grande que x
	static boolean ExisteElementoDebajo(ABBTDA A, int x){
		return alturaABB(A)>profundidad(A,x);
	}
	/*static int alturaABB (ABBTDA A){
		if(A.ABBVac�o())
			return 0;
		else{
			if(alturaABB(A.HijoIzq())>alturaABB(A.HijoDer()))
				return 1 + alturaABB(A.HijoIzq());
			else
				return 1 + alturaABB(A.HijoDer());
		}
	}
	static int profundidad (ABBTDA A, int x){
		if(A.Ra�z()==x)
			return 0;
		else{
			if(x>A.Ra�z())
				return 1 + profundidad(A.HijoDer(),x);
			else
				return 1 + profundidad(A.HijoIzq(),x);
		}
	}*/
	
	// Dado un ABB A y un entero N, escribir un m�todo externo que calcule cuentos elementos de A NO estan en el nivel N
	static int CantidadElemNivelNoN (ABBTDA A, int n){
		return cantidadElem(A) - cantidadElemEnNivel(A,n);
	}
	static int cantidadElemEnNivel(ABBTDA A, int n){
		if(A.ABBVac�o()){
			return 0;
		}else{
			if(n==0)
				return 1;
			else
				return cantidadElemEnNivel(A.HijoDer(),n-1) + cantidadElemEnNivel(A.HijoIzq(),n-1);
		}
	}
	static int cantidadElem(ABBTDA A){
		if(A.ABBVac�o()){
			return 0;
		}else{
			return 1 + cantidadElem(A.HijoIzq()) + cantidadElem(A.HijoDer());
		}
	}
	
	/* Dado un ABB A y un valor V (que se encuentra en A), determinar la m�xima profundidad de los nodos cuyo camino desde la ra�z de A 
	hasta ellos pasa por V */
	/*static int maximaProfundidad(ABBTDA A, int v){
		if(A.ABBVac�o())
			return 0;
		else{
			if(A.Ra�z()>v)
				return 1 + maximaProfundidad(A.HijoIzq(),v);
			else if(A.Ra�z()<v)
				return 1 + maximaProfundidad(A.HijoDer(),v);
			else{ // Llegue a v
				if(!A.HijoDer().ABBVac�o() && A.HijoIzq().ABBVac�o())
					return 1 + maximaProfundidad(A.HijoDer(),v);
				else if(A.HijoDer().ABBVac�o() && !A.HijoIzq().ABBVac�o())
					return 1 + maximaProfundidad(A.HijoIzq(),v);
				else if	(!A.HijoDer().ABBVac�o() && !A.HijoIzq().ABBVac�o() && (alturaABB(A.HijoIzq())>alturaABB(A.HijoDer())))
						return 1 + maximaProfundidad(A.HijoIzq(),v);
				else if (!A.HijoDer().ABBVac�o() && !A.HijoIzq().ABBVac�o() && (alturaABB(A.HijoIzq())<alturaABB(A.HijoDer())))
							return 1 + maximaProfundidad(A.HijoDer(),v);
				else 
					return 0;
			}
		}
	}*/
	
	// Dado un ABB A, determinar cuantos elementos de A NO tienen hermanos
	static int ContSinHermanos(ABBTDA a) {
		if(a.ABBVac�o())
			return 0;
		else{
			if(!a.HijoIzq().ABBVac�o()&&!a.HijoDer().ABBVac�o())
				return ContSinHermanos(a.HijoIzq())+ContSinHermanos(a.HijoDer());
			if(!a.HijoIzq().ABBVac�o()&&a.HijoDer().ABBVac�o())
				return ContSinHermanos(a.HijoIzq())+1;
			if(a.HijoIzq().ABBVac�o()&&!a.HijoDer().ABBVac�o())
				return ContSinHermanos(a.HijoDer())+1;
			return 0;
		}
	}
	
	// Dado un ABBTDA A, determinar el valor de la menor de las hojas de un �rbol (seg�n su valor)
	static int MenorValor (ABBTDA A){
		if(A.ABBVac�o()){
			return 0;
		}else{
			if(A.HijoIzq().ABBVac�o()&&A.HijoDer().ABBVac�o())
				return A.Ra�z();
			else
				return MenorValor(A.HijoIzq());
		}
	}
	
	// Dado un ABBTDA A, determinar el valor de la menor de las hojas de un �rbol (seg�n su nivel)
	static int menorHoja(ABBTDA a){
		if(a.ABBVac�o()){
			return 0;
		}else{
			if(a.HijoIzq().ABBVac�o()&&a.HijoDer().ABBVac�o())
				return a.Ra�z();
			if(menorHoja(a.HijoIzq())>menorHoja(a.HijoDer()))
				return menorHoja(a.HijoIzq());
			else 
				return menorHoja(a.HijoDer());
		  }
	}
	
	// Dado un ABB A, construir el conjunto de los elementos internos de A (que no son hojas)
	static void agregInt(ABBTDA A,ConjuntoTDA C){
		if (!A.ABBVac�o()){
			if(!A.HijoIzq().ABBVac�o()||!A.HijoDer().ABBVac�o()){
				C.Agregar(A.Ra�z());
				agregInt(A.HijoDer(),C);
				agregInt(A.HijoIzq(),C);
			}
		}
	}
	
	// Dado un ABB A y dos enteros v1 y v2, determinar si existe un camino desde la ra�z que pase por ambos valores
	static boolean valorExiste(ABBTDA A, int va){
		if(A.ABBVac�o())
			return false;
		else{
			if(va<A.Ra�z())
				return valorExiste(A.HijoIzq(), va);
			else
				return valorExiste(A.HijoDer(), va);
		}
	}
	static boolean existeCamino(ABBTDA A, int v1, int v2){
		if(A.ABBVac�o())
			return false;
		else{
			if(v1==A.Ra�z())
				return true && (valorExiste(A.HijoIzq(),v2) || valorExiste(A.HijoDer(),v2));
			else if(v2==A.Ra�z())
				return true && (valorExiste(A.HijoIzq(),v1) || valorExiste(A.HijoDer(),v1));
			else{
				if(v1<A.Ra�z() || v2<A.Ra�z())
					return existeCamino(A.HijoIzq(), v1, v2);
				else
					return existeCamino(A.HijoDer(), v1, v2);
			}
		}
	}
	
	// Imprimir por pantalla un ABB
	public static void imprimirABB(ABBTDA A){
		ABBGraph G = new ABBGraph();
		G.plot(A,"ABB");
	}
	
	public static void main(String[] args) {
		// DATOS
		ABBTDA A = new ABBDinamica();
		A.InicializarABB();
		A.AgregarElem(8);
		A.AgregarElem(5);
		A.AgregarElem(15);
		A.AgregarElem(4);
		A.AgregarElem(6);
		A.AgregarElem(7);
		A.AgregarElem(9);
		A.AgregarElem(20);
		A.AgregarElem(17);
		A.AgregarElem(18);
		A.AgregarElem(19);
		// M�TODOS
		imprimirABB(A);
		//System.out.println(maximaProfundidad(A,15));
		
	}

}
