package Ejercicios;

import Implementaciones.PilaEstatica1;
import Implementaciones.ConjuntoEstatica1;
import Interfaces.ConjuntoTDA;
import Interfaces.PilaTDA;

public class Pila {

	// TP1 - 2.a - Pasar una Pila a otra (dej�ndola en orden inverso)
	static void pasarPila(PilaTDA Origen, PilaTDA Destino){
		while(!Origen.PilaVac�a()){
			Destino.Apilar(Origen.Tope());
			Origen.Desapilar();
		}
	}
	
	// TP1 - 2.b - Copiar una Pila en otra (dej�ndola en el mismo orden que la original)
	static void pasarPilaOrden(PilaTDA Origen, PilaTDA Destino){
		PilaTDA aux = new PilaEstatica1();
		aux.InicializarPila();
		while(!Origen.PilaVac�a()){
			aux.Apilar(Origen.Tope());
			Origen.Desapilar();
		}
		while(!aux.PilaVac�a()){
			Destino.Apilar(aux.Tope());
			aux.Desapilar();
		}
	}
	
	// TP1 - 2.c - Invertir el contenido de una Pila.
	static void invertirPila(PilaTDA A){
		PilaTDA aux1 = new PilaEstatica1();
		aux1.InicializarPila();
		while(!A.PilaVac�a()){
			aux1.Apilar(A.Tope());
			A.Desapilar();
		}
		PilaTDA aux2 = new PilaEstatica1();
		aux2.InicializarPila();
		while(!aux1.PilaVac�a()){
			aux2.Apilar(aux1.Tope());
			aux1.Desapilar();
		}
		while(!aux2.PilaVac�a()){
			A.Apilar(aux2.Tope());
			aux2.Desapilar();
		}
	}
	
	// TP1 - 2.d - Contar los elementos de una Pila
	static int elementosPila(PilaTDA A){
		int cant = 0;
		while(!A.PilaVac�a()){
			A.Desapilar();
			cant++;
		}
		return cant;
	}
	
	// TP1 - 2.e - Sumar los elementos de una Pila
	static int sumaElementosPila(PilaTDA A){
		int suma = 0;
		while(!A.PilaVac�a()){
			suma = suma + A.Tope();
			A.Desapilar();
		}
		return suma;
	}
	
	// TP1 - 2.f - Calcular el promedio de los elementos de una Pila
	static float promedioElementosPila(PilaTDA A){
		int cant = 0;
		int suma = 0;
		while(!A.PilaVac�a()){
			cant++;
			suma = suma + A.Tope();
			A.Desapilar();
		}
		return (float)suma / (float)cant;
	}
	
	// TP3 - 1.a - Comprobar si una Pila P es capic�a (el elemento del tope es igual al de la base, el segundo igual al ante�ltimo, etc.)
	static boolean pilaCapicua(PilaTDA A){
		int cant = 0;
		PilaTDA aux = new PilaEstatica1();
		aux.InicializarPila();
		while(!A.PilaVac�a()){
			cant++;
			aux.Apilar(A.Tope());
			A.Desapilar();
		}
		if(cant%2==1){
			int mitad = cant/2;
			while(mitad!=0){
				A.Apilar(aux.Tope());
				aux.Desapilar();
				mitad--;
			}
			aux.Desapilar();
		}else{	
			cant = cant / 2;
			while(cant != 0){
				A.Apilar(aux.Tope());
				aux.Desapilar();
				cant--;
			}
		}
		while(!A.PilaVac�a() && !aux.PilaVac�a()){
			if(A.Tope() != aux.Tope())
				return false;
			else{
				A.Desapilar();
				aux.Desapilar();
			}
			if(A.PilaVac�a()&&!aux.PilaVac�a() || !A.PilaVac�a()&&aux.PilaVac�a())
				return false;
		}
		return true;
	}
	
	// TP3 - 1.b - Eliminar de una Pila P las repeticiones de elementos, dejando un representante de cada uno de los elementos presentes originalmente. Se deber� respetar el orden original de los elementos, y en el caso de los repetidos se conservar� el primero que haya ingresado en P.
	static void eliminarRepetidosPila(PilaTDA A){
		PilaTDA aux = new PilaEstatica1();
		aux.InicializarPila();
		PilaTDA fin = new PilaEstatica1();
		fin.InicializarPila();
		int cmp = 0;
		while(!A.PilaVac�a()){
			while(!A.PilaVac�a()){
				aux.Apilar(A.Tope());
				A.Desapilar();
			}
			cmp = aux.Tope();
			aux.Desapilar();
			while(!aux.PilaVac�a()){
				if(cmp != aux.Tope())
					A.Apilar(aux.Tope());
				aux.Desapilar();
			}
			fin.Apilar(cmp);
		}
		while(!fin.PilaVac�a()){
			A.Apilar(fin.Tope());
			fin.Desapilar();
		}
	}
	
	// TP3 - 1.c - Repartir una Pila P en dos mitades M1 y M2 de elementos consecutivos, respetando el orden. Asumir que la Pila P contiene un n�mero par de elementos.
	static void repartirPila(PilaTDA P, PilaTDA M1, PilaTDA M2){
		PilaTDA aux = new PilaEstatica1();
		aux.InicializarPila();
		int cant = 0;
		while(!P.PilaVac�a()){
			aux.Apilar(P.Tope());
			P.Desapilar();
			cant++;
		}
		while(!aux.PilaVac�a()){
			M1.Apilar(aux.Tope());
			aux.Desapilar();
		}
		cant = cant/2;
		while(cant != 0){
			cant--;
			M2.Apilar(M1.Tope());
			M1.Desapilar();
		}
		invertirPila(M2);
	}
	
	// TP3 - 1.d - Generar el conjunto de elementos que se repiten en una Pila.
	static void conjuntoRepetidosPila(PilaTDA P, ConjuntoTDA C){
		PilaTDA aux = new PilaEstatica1();
		aux.InicializarPila();
		int cmp;
		while(!P.PilaVac�a()){
			cmp = P.Tope();
			P.Desapilar();
			while(!P.PilaVac�a()){
				if(cmp==P.Tope()){
					if(!C.Pertenece(cmp))
						C.Agregar(cmp);
				}else
					aux.Apilar(P.Tope());
				P.Desapilar();
			}
			while(!aux.PilaVac�a()){
				P.Apilar(aux.Tope());
				aux.Desapilar();
			}
		}
	}
	
	// Imprimir por pantalla una pila
	public static void imprimirPila(PilaTDA A){
		PilaTDA aux = new PilaEstatica1();
		aux.InicializarPila();
		System.out.println("Pila:");
		while(!A.PilaVac�a()){
			System.out.println(A.Tope());
			aux.Apilar(A.Tope());
			A.Desapilar();
		}
		while(!aux.PilaVac�a()){
			A.Apilar(aux.Tope());
			aux.Desapilar();
		}
	}
			
	public static void main(String[] args) {
		// DATOS
		PilaTDA A = new PilaEstatica1();
		A.InicializarPila();
		ConjuntoTDA C = new ConjuntoEstatica1();
		C.InicializarConjunto();
		A.Apilar(1);
		A.Apilar(2);
		A.Apilar(3);
		A.Apilar(4);
		// EJERCICIOS
		imprimirPila(A);
	}

}
