package Ejercicios;

import Interfaces.ColaTDA;
import Interfaces.ConjuntoTDA;
import Interfaces.PilaTDA;
import Implementaciones.ColaDin�mica2;
import Implementaciones.ConjuntoEstatica1;
import Implementaciones.PilaEstatica1;

public class Cola {

	// TP1 - 4.a - Pasar una Cola a otra
	static void pasarCola(ColaTDA Origen, ColaTDA Destino){
		while(!Origen.ColaVac�a()){
			Destino.Acolar(Origen.Primero());
			Origen.Desacolar();
		}
	}
	
	// TP1 - 4.b - Invertir el contenido de una Cola (pueden usarse Pilas auxiliares)
	static void invertirCola1(ColaTDA A){
		PilaTDA aux = new PilaEstatica1();
		aux.InicializarPila();
		while(!A.ColaVac�a()){
			aux.Apilar(A.Primero());
			A.Desacolar();
		}
		while(!aux.PilaVac�a()){
			A.Acolar(aux.Tope());
			aux.Desapilar();
		}
	}
	
	// TP1 - 4.c - Invertir el contenido de una Cola (NO pueden usarse Pilas auxiliares)
	static void invertirCola2(ColaTDA A){
		ColaTDA aux = new ColaDin�mica2();
		aux.InicializarCola();
		ColaTDA inv = new ColaDin�mica2();
		inv.InicializarCola();
		int ult = 0;
		while(!A.ColaVac�a()){
			while(!A.ColaVac�a()){
				ult = A.Primero();
				A.Desacolar();
				if(!A.ColaVac�a())
					aux.Acolar(ult);
			}
			inv.Acolar(ult);
			while(!aux.ColaVac�a()){
				A.Acolar(aux.Primero());
				aux.Desacolar();
			}
		}
		while(!inv.ColaVac�a()){
			A.Acolar(inv.Primero());
			inv.Desacolar();
		}
	}
	
	// TP1 - 4.d - Determinar si el final de la Cola C1 coincide o no con la Cola C2.
	static boolean finalColaIgual(ColaTDA A, ColaTDA B){
		PilaTDA auxA = new PilaEstatica1();
		auxA.InicializarPila();
		PilaTDA auxB = new PilaEstatica1();
		auxB.InicializarPila();
		while(!A.ColaVac�a()){
			auxA.Apilar(A.Primero());
			A.Desacolar();
		}
		while(!B.ColaVac�a()){
			auxB.Apilar(B.Primero());
			B.Desacolar();
		}
		return auxA.Tope()==auxB.Tope();
	}
	
	// TP1 - 4.e - Determinar si una Cola es capic�a o no. Para ser capic�a debe cumplir que el primer elemento es igual al �ltimo, el segundo igual al pen�ltimo, etc.
	static boolean colaCapic�a(ColaTDA A){
		int cant = 0;
		ColaTDA aux = new ColaDin�mica2();
		aux.InicializarCola();
		while(!A.ColaVac�a()){
			cant++;
			aux.Acolar(A.Primero());
			A.Desacolar();
		}
		int mitad = cant/2;
		while(mitad>0 && !aux.ColaVac�a()){
			A.Acolar(aux.Primero());
			aux.Desacolar();
			mitad--;
			
		}
		if(cant%2==1) // Si hay cantidad de elementos impar
			aux.Desacolar();
		invertirCola1(A);
		while(!aux.ColaVac�a() && !A.ColaVac�a()){
			if(aux.Primero()!=A.Primero())
				return false;
			aux.Desacolar();
			A.Desacolar();
		}
		if(aux.ColaVac�a()&&!A.ColaVac�a() || !aux.ColaVac�a()&&A.ColaVac�a())
			return false;
		return true;	
	}
	
	// TP1 - 4.f - Determinar si la Cola C1 es la inversa de la Cola C2. Dos Colas ser�n inversas, si tienen los mismos elementos pero en orden inverso
	static boolean colaInversa(ColaTDA A, ColaTDA B){
		invertirCola1(A);
		while(!A.ColaVac�a() && !B.ColaVac�a()){
			if(A.Primero() != B.Primero())
				return false;
			else{
				A.Desacolar();
				B.Desacolar();
			}
			if(A.ColaVac�a() || B.ColaVac�a())
				return false;
		}
		return true;
	}
	
	/* TP3 - 2.a - Eliminar de una Cola C las repeticiones de elementos, dejando un representante de cada uno de los elementos presentes 
	originalmente. Se deber� respetar el orden original de los elementos, y en el caso de los repetidos se conservar� el primero que haya
	ingresado en C */
	static void eliminarRepetidos(ColaTDA C){
		ColaTDA aux = new ColaDin�mica2();
		aux.InicializarCola();
		ColaTDA fin = new ColaDin�mica2();
		fin.InicializarCola();
		int cmp;
		while(!C.ColaVac�a()){
			cmp = C.Primero();
			C.Desacolar();
			while(!C.ColaVac�a()){
				if(cmp != C.Primero())
					aux.Acolar(C.Primero());
				C.Desacolar();
			}
			fin.Acolar(cmp);
			while(!aux.ColaVac�a()){
				C.Acolar(aux.Primero());
				aux.Desacolar();
			}
		}
		while(!fin.ColaVac�a()){
			C.Acolar(fin.Primero());
			fin.Desacolar();
		}
	}
	
	/* TP3 - 2.b - Repartir una Cola C en dos mitades M1 y M2 de elementos consecutivos respetando el orden. Asumir que la cantidad de 
	elementos de C es par */
	static void repartirCola(ColaTDA C, ColaTDA M1, ColaTDA M2){
		int cant = 0;
		while(!C.ColaVac�a()){
			cant++;
			M2.Acolar(C.Primero());
			C.Desacolar();
		}
		cant = cant/2;
		while(cant!=0){
			M1.Acolar(M2.Primero());
			M2.Desacolar();
			cant--;
		}
	}
		
	// TP3 - 2.c -  Generar el conjunto de elementos que se repiten en una Cola,
	static void conjuntoRepetidosCola(ColaTDA P, ConjuntoTDA C){
		ColaTDA aux = new ColaDin�mica2();
		aux.InicializarCola();
		int cmp;
		while(!P.ColaVac�a()){
			cmp = P.Primero();
			P.Desacolar();
			while(!P.ColaVac�a()){
				if(cmp == P.Primero())
					C.Agregar(cmp);
				else
					aux.Acolar(P.Primero());
				P.Desacolar();
			}
			while(!aux.ColaVac�a()){
				P.Acolar(aux.Primero());
				aux.Desacolar();
			}
		}
	}
	
	// Imprimir por pantalla una cola
	public static void imprimirCola(ColaTDA A){
		ColaTDA aux = new ColaDin�mica2();
		aux.InicializarCola();
		System.out.println("Cola:");
		while(!A.ColaVac�a()){
			aux.Acolar(A.Primero());
			System.out.print(A.Primero()+" ");
			A.Desacolar();
		}
		while(!aux.ColaVac�a()){
			A.Acolar(aux.Primero());
			aux.Desacolar();
		}
		System.out.println();
	}
	
	public static void main(String[] args) {
		// DATOS
		ColaTDA A = new ColaDin�mica2();
		A.InicializarCola();
		ConjuntoTDA rep = new ConjuntoEstatica1();
		rep.InicializarConjunto();
		A.Acolar(1);
		A.Acolar(2);
		A.Acolar(2);
		A.Acolar(7);
		A.Acolar(1);
		// EJERCICIOS
		imprimirCola(A);
	}

}
