package Ejercicios;

import Implementaciones.ConjuntoEstatica1;
import Implementaciones.DiccionarioMultipleDinamica;
import Interfaces.ConjuntoTDA;
import Interfaces.DiccionarioMultipleTDA;

public class DiccionarioMultiple {
	
	/* TP3 - 5.1.a -  A partir del TDA Diccionario, escribir distintos m�todos externos que permitan, dados dos DiccionarioMultipleTDA D1 y D2, 
	generar un DiccionarioMultipleTDA que contenga: las claves presentes en D1 y D2, con todos los elementos asociados a cada clave. */
	static DiccionarioMultipleTDA combinarDM(DiccionarioMultipleTDA D1, DiccionarioMultipleTDA D2){
		DiccionarioMultipleTDA D3 = new DiccionarioMultipleDinamica();
		ConjuntoTDA claves = D1.Claves();
		ConjuntoTDA valores = new ConjuntoEstatica1();
		int clave, valor;
		while(!claves.ConjuntoVac�o()){
			clave = claves.Elegir();
			claves.Sacar(clave);
			valores = D1.Recuperar(clave);
			while(!valores.ConjuntoVac�o()){
				valor = valores.Elegir();
				valores.Sacar(valor);
				D3.Agregar(clave, valor);
			}
		}
		claves = D2.Claves();
		while(!claves.ConjuntoVac�o()){
			clave = claves.Elegir();
			claves.Sacar(clave);
			valores = D2.Recuperar(clave);
			while(!valores.ConjuntoVac�o()){
				valor = valores.Elegir();
				valores.Sacar(valor);
				D3.Agregar(clave, valor);
			}
		}
		return D3;
	}
	
	/* TP3 - 5.1.b -  A partir del TDA Diccionario, escribir distintos m�todos externos que permitan, dados dos DiccionarioMultipleTDA D1 y D2, 
	generar un DiccionarioMultipleTDA que contenga: las claves presentes en D1 y D2, con todos los elementos comunes a las claves coincidentes
	en ambos. */
		
	
	/* TP3 - 5.1.c -  A partir del TDA Diccionario, escribir distintos m�todos externos que permitan, dados dos DiccionarioMultipleTDA D1 y D2, 
	generar un DiccionarioMultipleTDA que contenga: las claves comunes de D1 y D2, con todos los elementos asociados a cada clave. */
	static DiccionarioMultipleTDA clavesComunes(DiccionarioMultipleTDA D1, DiccionarioMultipleTDA D2){
		DiccionarioMultipleTDA D3 = new DiccionarioMultipleDinamica();
		D3.InicializarDiccionario();
		ConjuntoTDA claves1 = D1.Claves();
		ConjuntoTDA claves2 = D2.Claves();
		ConjuntoTDA valores1, valores2;
		int clave, aux;
		while(!claves1.ConjuntoVac�o()){
			clave = claves1.Elegir();
			claves1.Sacar(clave);
			if(claves2.Pertenece(clave)){ // Esta en ambas, guardo todos los valores
				valores1 = D1.Recuperar(clave);
				while(!valores1.ConjuntoVac�o()){
					aux = valores1.Elegir();
					valores1.Sacar(aux);
					D3.Agregar(clave, aux);
				}
				valores2 = D2.Recuperar(clave);
				while(!valores2.ConjuntoVac�o()){
					aux = valores2.Elegir();
					valores2.Sacar(aux);
					D3.Agregar(clave, aux);
				}
			}
		}
		return D3;
	}
	
	/* TP3 - 5.1.d -  A partir del TDA Diccionario, escribir distintos m�todos externos que permitan, dados dos DiccionarioMultipleTDA D1 y D2, 
	generar un DiccionarioMultipleTDA que contenga: las claves comunes de D1 y D2, con todos los elementos comunes a las claves
	coincidentes en ambos. */
	static DiccionarioMultipleTDA valoresCoincidentes (DiccionarioMultipleTDA D1, DiccionarioMultipleTDA D2){
		DiccionarioMultipleTDA D3 = new DiccionarioMultipleDinamica();
		D3.InicializarDiccionario();
		ConjuntoTDA claves1 = D1.Claves();
		ConjuntoTDA claves2 = D2.Claves();
		int clave;
		while(!claves1.ConjuntoVac�o()){
			clave = claves1.Elegir();
			claves1.Sacar(clave);
			if(claves2.Pertenece(clave)){
				int valor;
				ConjuntoTDA valores1 = D1.Recuperar(clave);
				ConjuntoTDA valores2 = D2.Recuperar(clave);
				while(!valores1.ConjuntoVac�o()){			
					valor = valores1.Elegir();
					valores1.Sacar(valor);
					if(valores2.Pertenece(valor)){
						D3.Agregar(clave, valor);
					}
				}
			}	
		}
		return D3;
	}
	
	// Mostrar por pantalla un Diccionario Multiple
	public static void imprimirDM(DiccionarioMultipleTDA DM){
		System.out.println("DICCIONARIO M�LTIPLE (Clave - Valores)");
		ConjuntoTDA C = new ConjuntoEstatica1();
		C.InicializarConjunto();
		C = DM.Claves();
		if(!C.ConjuntoVac�o()){
			int auxC, auxV;
			ConjuntoTDA V = new ConjuntoEstatica1();
			V.InicializarConjunto();
			while(!C.ConjuntoVac�o()){
				auxC = C.Elegir(); // Saco la clave
				V = DM.Recuperar(auxC); // Saco todos los valores (m�nimo uno)
				System.out.print(auxC+" - {");
				while(!V.ConjuntoVac�o()){
					auxV = V.Elegir();
					V.Sacar(auxV);
					if(!V.ConjuntoVac�o())
						System.out.print(auxV+",");
					else
						System.out.print(auxV+"}");
				}
				System.out.println();
				C.Sacar(auxC);
			}
		}else{
			System.out.println("(Vac�o)");
		}
	}
	
	public static void main(String[] args) {
		// DATOS
		DiccionarioMultipleTDA DM1 = new DiccionarioMultipleDinamica();
		DM1.InicializarDiccionario();
		DM1.Agregar(1, 2);
		DM1.Agregar(2, 3);
		DM1.Agregar(3, 2);
		DiccionarioMultipleTDA DM2 = new DiccionarioMultipleDinamica();
		DM2.InicializarDiccionario();
		DM2.Agregar(2, 3);
		DM2.Agregar(1, 3);
		// M�TODOS
		imprimirDM(valoresCoincidentes(DM1,DM2));
	}

}
