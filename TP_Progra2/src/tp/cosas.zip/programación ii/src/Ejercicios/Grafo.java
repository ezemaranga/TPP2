package Ejercicios;

import Interfaces.ConjuntoTDA;
import Interfaces.GrafoTDA;
import Recursos.GrafoGraph;
import Implementaciones.ConjuntoEstatica1;
import Implementaciones.GrafoEstatica;

public class Grafo {
	
	/*  TP6 - 4 - Dado un Grafo G y un v�rtice v, calcular el conjunto de v�rtices AdyacentesDobles de v.
	Se define que un v�rtice w es adyacente doble de un v�rtice v, si existe otro v�rtice x y hay
	una arista que comienza en v y termina en x y otra que comienza en x y termina en w */
	// V�rtices adyacentes a un v�rtices son los vertices a los que apunta el mismo.
	static ConjuntoTDA verticesAdyacentes(GrafoTDA G, int v){
		ConjuntoTDA vertices = G.Vertices();
		ConjuntoTDA adyacentes = new ConjuntoEstatica1();
		adyacentes.InicializarConjunto();
		while(!vertices.ConjuntoVac�o()){
			int vdest = vertices.Elegir();
			vertices.Sacar(vdest);
			if(G.ExisteArista(v, vdest))
				adyacentes.Agregar(vdest);
		}
		return adyacentes;
	}
	// Adyacentes dobles son los vertices adyacentes de los adyacentes a uno.
	static ConjuntoTDA verticesAdyacentesDobles(GrafoTDA G, int v){
		ConjuntoTDA adyacentes = verticesAdyacentes(G,v);
		ConjuntoTDA adyacentesDobles = new ConjuntoEstatica1();
		adyacentesDobles.InicializarConjunto();
		while(!adyacentes.ConjuntoVac�o()){
			int va = adyacentes.Elegir();
			adyacentes.Sacar(va);
			ConjuntoTDA AA = verticesAdyacentes(G,va);
			while(!AA.ConjuntoVac�o()){
				int vaa = AA.Elegir();
				AA.Sacar(vaa);
				adyacentesDobles.Agregar(vaa);
			}
		}
		return adyacentesDobles;
	}
	
	// TP6 - 5 - Dado un v�rtice v de un grafo, calcular el mayor de los costos de las aristas salientes
	static int mayorCostoVertice(GrafoTDA G, int v){
		ConjuntoTDA vertices = G.Vertices();
		int aux, max=0;
		while(!vertices.ConjuntoVac�o()){
			aux = vertices.Elegir();
			vertices.Sacar(aux);
			if(G.ExisteArista(v, aux) && G.PesoArista(v,aux)>max)
				max = G.PesoArista(v,aux);
		}
		return max;
	}

	/*  TP6 - 6 - Dado un Grafo G y un v�rtice v, escribir un m�todo que permita obtener el conjunto de 
	los Predecesores del v�rtice v en G. Se define que un v�rtice o es predecesor de otro v�rtice d, si 
	hay una arista que comienza en o y termina en d */
	static ConjuntoTDA verticesPredecesores(GrafoTDA G, int v){
		ConjuntoTDA predecesores = new ConjuntoEstatica1();
		predecesores.InicializarConjunto();
		ConjuntoTDA vertices = G.Vertices();
		int aux;
		while(!vertices.ConjuntoVac�o()){
			aux = vertices.Elegir();
			vertices.Sacar(aux);
			if(G.ExisteArista(aux, v))
				predecesores.Agregar(aux);
		}
		return predecesores;
	}
	
	/* TP6 - 7 Dado un Grafo G escribir un m�todo que permita obtener el conjunto de los v�rtices aislados
	en G. Se define que un v�rtice v es aislado si v no tiene aristas entrantes ni salientes */
	static ConjuntoTDA verticesAislados(GrafoTDA G){
		ConjuntoTDA aislados = new ConjuntoEstatica1();
		aislados.InicializarConjunto();
		ConjuntoTDA vertices1 = G.Vertices();
		ConjuntoTDA vertices2 = new ConjuntoEstatica1();
		vertices2.InicializarConjunto();
		int v1, v2;
		boolean existe;
		while(!vertices1.ConjuntoVac�o()){
			v1 = vertices1.Elegir();
			vertices1.Sacar(v1);
			vertices2 = G.Vertices();
			existe = false;
			while(!vertices2.ConjuntoVac�o()){
				v2 = vertices2.Elegir();
				vertices2.Sacar(v2);
				if(G.ExisteArista(v1, v2) || G.ExisteArista(v2, v1))
					existe = true;
			}
			if(!existe)
				aislados.Agregar(v1);
		}
		return aislados;
	}
	
	/*  TP6 - 8 Dado un Grafo G y dos v�rtices v1 y v2, escribir un m�todo que permita obtener el conjunto
	de todos los v�rtices puente entre v1 y v2. Se define que un v�rtice p es puente entre dos v�rtices o 
	y d, si hay una arista que comienza en o y termina en p y otra que comienza en p y termina en d */
	static ConjuntoTDA verticesPuente(GrafoTDA G, int v1, int v2){
		ConjuntoTDA puente = new ConjuntoEstatica1();
		puente.InicializarConjunto();
		ConjuntoTDA vertices = G.Vertices();
		int aux;
		while(!vertices.ConjuntoVac�o()){
			aux = vertices.Elegir();
			vertices.Sacar(aux);
			if(G.ExisteArista(v1, aux)&&G.ExisteArista(aux, v2) || G.ExisteArista(v2, aux)&&G.ExisteArista(aux, v1))
				puente.Agregar(aux);
		}
		return puente;
	}
	
	/*  TP6 - 9 Dado un Grafo G y un v�rtice v, calcular el grado de v. Se define el grado de un v�rtice v 
	como el entero que es igual a la resta entre la cantidad de aristas que salen de v menos la cantidad 
	de aristas que llegan a v.*/
	// Se llama grado de un vertice a la cantidad de predecesores menos la cantidad de adyacentes
	static int gradoVertice1(GrafoTDA G, int v){
		int grado = 0;
		ConjuntoTDA vertices = G.Vertices();
		while(!vertices.ConjuntoVac�o()){
			int otro = vertices.Elegir();
			vertices.Sacar(otro);
			if(G.ExisteArista(v, otro))
				grado++;
			if(G.ExisteArista(otro, v))
				grado--;
		}
		return grado;
	}
	static int gradoVertice2(GrafoTDA G, int v){
		ConjuntoTDA verticesPredecesores = verticesPredecesores(G,v);
		ConjuntoTDA verticesAdyacentes = verticesAdyacentes(G,v);
		int cp=0, ca=0;
		while(!verticesPredecesores.ConjuntoVac�o()){
			verticesPredecesores.Sacar(verticesPredecesores.Elegir());
			cp++;
		}
		while(!verticesAdyacentes.ConjuntoVac�o()){
			verticesAdyacentes.Sacar(verticesAdyacentes.Elegir());
			ca++;
		}
		return cp-ca;
	}
	
	/* Escribir un algoritmo que reciba un grafo y un valor X y devuelva la cantidad de aristas entrantes que posee el nodo de 
	valor X mas las de todos los nodos que son multiplos de X */
	public static int cantAristas(GrafoTDA G, int x){
		ConjuntoTDA Vertices = G.Vertices();
		ConjuntoTDA Vertices2= G.Vertices();
		int v, con=0, v2;	
		while(!Vertices.ConjuntoVac�o()){
			v=Vertices.Elegir();
			Vertices.Sacar(v);
			if (G.ExisteArista(v, x))
				con++;
			if(v%x==0 && x!=v){
				Vertices2 = G.Vertices();
				while(!Vertices2.ConjuntoVac�o()){
					v2= Vertices2.Elegir();
					Vertices2.Sacar(v2);
					if(G.ExisteArista(v2, v))
						con++;
				}
			}			
		}
		return con;			
	}

	
	// Imprimir por pantalla un Grafo
	public static void imprimirGrafo(GrafoTDA G){
		GrafoGraph graph = new GrafoGraph(G,"Grafo");
	}
	
	public static void main(String[] args) {
		// DATOS
		GrafoTDA G = new GrafoEstatica();
		G.InicializarGrafo();
		G.AgregarVertice(1);
		G.AgregarVertice(2);
		G.AgregarVertice(3);
		G.AgregarVertice(4);
		G.AgregarArista(1, 2, 2);
		G.AgregarArista(2, 3, 9);
		G.AgregarArista(1, 3, 4);
		G.AgregarArista(1, 1, 6);
		// M�TODOS
		imprimirGrafo(G);
	}

}