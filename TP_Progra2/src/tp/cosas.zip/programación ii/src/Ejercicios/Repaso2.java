package Ejercicios;

import Interfaces.ABBTDA;
import Interfaces.DiccionarioSimpleTDA;
import Interfaces.ConjuntoTDA;
import Interfaces.DiccionarioMultipleTDA;
import Interfaces.GrafoTDA;
import Implementaciones.ABBDinamica;
import Implementaciones.DiccionarioSimpleEstatica;
import Implementaciones.ConjuntoEstatica1;
import Implementaciones.DiccionarioMultipleEstatica;
import Implementaciones.GrafoEstatica;
import Recursos.ABBGraph;
import Recursos.GrafoGraph;

public class Repaso2 {
	
	/* 1 - Dado un ABB A, escribir un m�todo que calcule cuantos de sus nodos son nodo promedio.
	Se dice que un nodo de un ABB es un nodo promedio si su valor es el promedio de los
	valores de las ra�ces de sus hijos. Si el nodo no tiene ambos hijos, no podr� ser un nodo
	promedio.*/
	static int CantidadNodosPromedio(ABBTDA A){
		if (A.ABBVac�o())
			return 0;
		else if (!A.HijoDer().ABBVac�o() && !A.HijoIzq().ABBVac�o() && A.Ra�z()==(A.HijoDer().Ra�z()+A.HijoIzq().Ra�z())/2)
			return 1 + CantidadNodosPromedio(A.HijoIzq()) + CantidadNodosPromedio(A.HijoDer());
		else
			return CantidadNodosPromedio(A.HijoIzq()) + CantidadNodosPromedio(A.HijoDer());
	}
	
	/* 2 - Dado un ABB A y dos enteros min y max, escribir un m�todo que permita calcular cuantos
	elementos de A tienen valor entre min y max.*/
	static int CantidadElementosIntervalo(ABBTDA A, int min, int max){
		if(A.ABBVac�o())
			return 0;
		else if(A.Ra�z()>min && A.Ra�z()<max)
				return 1+ CantidadElementosIntervalo(A.HijoIzq(), min, max) + CantidadElementosIntervalo(A.HijoDer(), min, max);
			else
				return CantidadElementosIntervalo(A.HijoIzq(), min, max) + CantidadElementosIntervalo(A.HijoDer(), min, max); 
	}
	
	/* 3 - Dado un ABB A escribir un m�todo que permita determinar si A es compacto.
	Un ABB es compacto, si los valores de sus elementos son todos consecutivos.*/
	static boolean ABBCompacto(ABBTDA A){
		if(A.ABBVac�o())
			return true;
		else{
			if (!A.HijoIzq().ABBVac�o() && A.HijoDer().ABBVac�o() && A.Ra�z()==(A.HijoIzq().Ra�z()+1))
				return true && ABBCompacto(A.HijoIzq());
			else if (A.HijoIzq().ABBVac�o() && !A.HijoDer().ABBVac�o() && A.Ra�z()==(A.HijoDer().Ra�z()-1))
				return true && ABBCompacto(A.HijoDer());
			else if (!A.HijoDer().ABBVac�o() && !A.HijoIzq().ABBVac�o() && A.Ra�z()==(A.HijoIzq().Ra�z()+1) && A.Ra�z()==(A.HijoDer().Ra�z()-1))
				return true && ABBCompacto(A.HijoDer()) && ABBCompacto(A.HijoIzq());
			else if (A.HijoIzq().ABBVac�o() && A.HijoDer().ABBVac�o())
				return ABBCompacto(A.HijoDer()) && ABBCompacto(A.HijoIzq());
			else
				return false;
		}
	}
	
	/* 4 - Dado un ABB A escribir un m�todo que calcule cuantos de sus nodos tienen hermano.
	En un ABB, un nodo n tiene hermano si hay otro nodo que tiene el mismo padre que n.*/
	static int cantidadHermanosABB(ABBTDA A){
		if(A.ABBVac�o())
			return 0;
		else{
			if(!A.HijoDer().ABBVac�o() && !A.HijoIzq().ABBVac�o())
				return 1 + cantidadHermanosABB(A.HijoDer()) + cantidadHermanosABB(A.HijoIzq());
			else if (!A.HijoDer().ABBVac�o()&&A.HijoIzq().ABBVac�o() || A.HijoDer().ABBVac�o()&&!A.HijoIzq().ABBVac�o())
				return cantidadHermanosABB(A.HijoDer()) + cantidadHermanosABB(A.HijoIzq());
			else
				return 0;
		}
	}
	
	/* 5 - Determinar si un ABB es completo. Se dice que un ABB es completo si todos sus nodos cumplen con que la cantidad de elementos 
	de su hijo izquierdo es igual a la cantidad de elementos de su hijo derecho.*/
	static boolean ABBCompleto(ABBTDA A){
		if (A.ABBVac�o())
			return true;
		else if (!A.HijoIzq().ABBVac�o() && !A.HijoDer().ABBVac�o() || (A.HijoIzq().ABBVac�o() && A.HijoDer().ABBVac�o()))
				return true && ABBCompleto (A.HijoDer()) && ABBCompleto(A.HijoIzq());
			else
				return false;
	}
	
	/* 6 - Dado un ABB A y un elemento e que se encuentra en A, determinar la suma de los valores desde la ra�z hasta e (ambos inclusive).*/
	static int sumaValoresCamino(ABBTDA A, int e){
		if(A.ABBVac�o())
			return 0;
		else 
			if(A.Ra�z()==e){
				return A.Ra�z();
			}else if(A.Ra�z()>e)
				return A.Ra�z() + sumaValoresCamino(A.HijoIzq(), e);
			else if(A.Ra�z()<e)
				return A.Ra�z() + sumaValoresCamino(A.HijoDer(), e);
			else
				return 0;
	}
	
	// 7 - Dado un DiccionarioSimple DS, escribir un m�todo externo que determine cuantas claves de DS tienen asociadas a ellas mismas como valor
	static int DSClaveValorIgual(DiccionarioSimpleTDA DS){
		ConjuntoTDA claves = DS.Claves();
		int clave, valor, i=0;
		while(!claves.ConjuntoVac�o()){
			clave = claves.Elegir();
			claves.Sacar(clave);
			valor = DS.Recuperar(clave);
			if (clave == valor)
				i++;
		}
		return i;
	}
	
	/* 8 - Dado un DiccionarioSimple DS, generar otro DiccionarioSimple donde las claves sean los valores de DS y el valor asociado a cada 
	clave es la cantidad de veces que aparec�a en DS */
	static DiccionarioSimpleTDA invertirDiccionario(DiccionarioSimpleTDA A){
		DiccionarioSimpleTDA nuevo = new DiccionarioSimpleEstatica();
		nuevo.InicializarDiccionario();
		ConjuntoTDA claves = new ConjuntoEstatica1();
		claves.InicializarConjunto();
		claves = A.Claves();
		ConjuntoTDA valores = new ConjuntoEstatica1();
		valores.InicializarConjunto();
		int clave, valor, aux;
		while(!claves.ConjuntoVac�o()){
			clave = claves.Elegir();
			claves.Sacar(clave);
			valor = A.Recuperar(clave);
			// Verifico si ya est� en el nuevo diccionario
			valores = nuevo.Claves();
			if(valores.Pertenece(valor)){ // Ya estaba, sumo uno al valor ya existente
				aux = nuevo.Recuperar(valor);
				aux++;
				nuevo.Agregar(valor, aux);
			}else{ // Agrego con valor 1
				nuevo.Agregar(valor, 1);
			}
		}
		return nuevo;
	}
	
	// 9 - Dado un DiccionarioMultiple DM, determinar si hay alg�n valor que est� asociado a todas las claves de DM
	static boolean valorDMclaves(DiccionarioMultipleTDA DM){
		ConjuntoTDA claves = new ConjuntoEstatica1();
		claves.InicializarConjunto();
		claves = DM.Claves();
		ConjuntoTDA valores = new ConjuntoEstatica1();
		valores.InicializarConjunto();
		ConjuntoTDA valoresclave = new ConjuntoEstatica1();
		valoresclave.InicializarConjunto();
		int aux, x, sacar;
		// valores tiene todos los valores asociados a todas las claves
		while(!claves.ConjuntoVac�o()){
			aux = claves.Elegir();
			claves.Sacar(aux);
			valores = DM.Recuperar(aux);
		}
		// Veo si algun valor en valores esta asociado a todas las claves
		while(!valores.ConjuntoVac�o()){
			claves = DM.Claves();
			x = valores.Elegir();
			while(!claves.ConjuntoVac�o()){ // Veo si esta asociado a todas las claves
				aux = claves.Elegir();
				claves.Sacar(aux);
				valoresclave = DM.Recuperar(aux);
				if(!valoresclave.Pertenece(x)){
					valores.Sacar(x);
					while(!claves.ConjuntoVac�o()){
						claves.Sacar(claves.Elegir());
					}
				}else
					while(!valoresclave.ConjuntoVac�o()){
						valoresclave.Sacar(valoresclave.Elegir());	
					}
					if(claves.ConjuntoVac�o())
						return true;
			}
		}
		return false;
	}
	
	/* 10 - Dado un DiccionarioMultipleTDA DM, escribir un m�todo externo que permita devolver el menor valor asociado a la menor clave de DM */
	static int menorClaveDiccionario(DiccionarioMultipleTDA DM){
		ConjuntoTDA claves = new ConjuntoEstatica1();
		claves.InicializarConjunto();
		ConjuntoTDA valores = new ConjuntoEstatica1();
		valores.InicializarConjunto();
		int cmp, menorClave, menorValor;
		claves = DM.Claves();
		menorClave = claves.Elegir();
		claves.Sacar(menorClave);
		while(!claves.ConjuntoVac�o()){
			cmp = claves.Elegir();
			claves.Sacar(cmp);
			if(cmp<menorClave)
				menorClave = cmp;
		}
		valores = DM.Recuperar(menorClave);
		menorValor = valores.Elegir();
		valores.Sacar(menorValor);
		while(!valores.ConjuntoVac�o()){
			cmp = valores.Elegir();
			valores.Sacar(cmp);
			if(cmp<menorValor)
				menorValor = cmp;
		}
		return menorValor;
	}
	
	/* 11 - Mostrar la generaci�n del AVL paso a paso (rotando cuando sea necesario) que se obtiene al incorporar los siguientes valores en el 
	orden dado: 15, 10, 25, 17, 13, 2, 5, 29, 40, 32, 12, 14, 3, 8, 50, 47, 43, 21, 9, 41, 35, 38, 1, 44 */
	
	/* 12 - Mostrar el armado(*) del �rbol B con t=2 (es decir todo nodo, salvo la ra�z, tiene entre 2 y 4 elementos y a lo sumo 5 hijos), 
	incorporando los siguientes valores (en ese orden): 2,100, 48, 73, 15, 12, 64, 33, 9, 5, 51, 60, 22, 81, 45, 66, 61, 77, 27
	(*) puede s�lo mostrarse los pasos en los que hay reestructuraci�n de nodos */
	
	/* 13 - Dado un Grafo G, determinar si es completo o no, respondiendo true o false respectivamente. Un grafo es completo si todos sus 
	v�rtices tienen una arista hacia (est�n conectados con) los restantes v�rtices */
	static boolean grafoCompleto(GrafoTDA G){
		ConjuntoTDA vertices1 = G.Vertices();
		ConjuntoTDA vertices2 = G.Vertices();
		int v1, v2;
		while(!vertices1.ConjuntoVac�o()){
			v1 = vertices1.Elegir();
			vertices1.Sacar(v1);
			vertices2 = G.Vertices();
			while(!vertices2.ConjuntoVac�o()){
				v2 = vertices2.Elegir();
				vertices2.Sacar(v2);
				if(v1!=v2 && (!G.ExisteArista(v1, v2)||!G.ExisteArista(v2, v1)))
					return false;
			}
		}
		return true;
	}
	
	/* 14 - Dado un Grafo G, determinar si tiene o no nodos aislados, respondiendo true o false	respectivamente. Un nodo de un grafo est� 
	aislado si no tiene aristas salientes ni entrantes */
	static boolean grafoNodoAislado(GrafoTDA G){
		ConjuntoTDA vertices1 = G.Vertices();
		ConjuntoTDA vertices2;
		int v1, v2;
		boolean existe = true; // Asumo que tiene vertices aislados
		while(!vertices1.ConjuntoVac�o()){
			v1 = vertices1.Elegir();
			vertices1.Sacar(v1);
			vertices2 = G.Vertices();
			existe = true;
			while(!vertices2.ConjuntoVac�o()){
				v2 = vertices2.Elegir();
				vertices2.Sacar(v2);
				if(G.ExisteArista(v1, v2) || G.ExisteArista(v2, v1))
					existe = false;
			}
			if(vertices2.ConjuntoVac�o() && existe)
				return true;
		}
		return false;
	}
	
	/* 15 - Determinar el Flujo total de un Grafo G. El flujo total de un grafo G es la suma de los flujos de todos sus v�rtices. El flujo 
	de un v�rtice v es la suma de los pesos de las aristas salientes de v, menos la suma de los pesos de las aristas entrantes en v */
	static int flujoTotalGrafo(GrafoTDA G){
		ConjuntoTDA vertices1 = G.Vertices();
		ConjuntoTDA vertices2;
		int v1, v2, flujo=0, total=0;
		while(!vertices1.ConjuntoVac�o()){
			v1 = vertices1.Elegir();
			vertices1.Sacar(v1);
			vertices2 = G.Vertices();
			while(!vertices2.ConjuntoVac�o()){
				v2 = vertices2.Elegir();
				vertices2.Sacar(v2);
				if(G.ExisteArista(v1, v2))
					flujo += G.PesoArista(v1, v2);
				if(G.ExisteArista(v2, v1))
					flujo -= G.PesoArista(v2, v1);
			}
			total += flujo;
			flujo = 0;
		}
		return total;
	}
	
	/* 16 - Dado un Grafo G, determinar cu�l es el n�mero de conexiones del v�rtice m�s conectado (contando aristas entrantes y aristas 
	salientes) con el resto de los v�rtices */
	static int conexionesGrafo(GrafoTDA G){
		ConjuntoTDA vertices1 = G.Vertices();
		ConjuntoTDA vertices2;
		int v1, v2, aux, max=0;
		while(!vertices1.ConjuntoVac�o()){
			v1 = vertices1.Elegir();
			vertices1.Sacar(v1);
			vertices2 = G.Vertices();
			aux=0;
			while(!vertices2.ConjuntoVac�o()){
				v2 = vertices2.Elegir();
				vertices2.Sacar(v2);
				if(G.ExisteArista(v1, v2))
					aux++;
				if(v1!=v2 && G.ExisteArista(v2,v1))
					aux++;
			}
			if(aux>max)
				max=aux;
		}
		return max;
	}
	
	public static void main(String[] args) {
		// DATOS
		// M�TODOS
	}

}