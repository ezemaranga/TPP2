package Ejercicios;

import Implementaciones.ConjuntoEstatica1;
import Implementaciones.PilaEstatica1;
import Interfaces.ColaTDA;
import Interfaces.ConjuntoTDA;
import Interfaces.PilaTDA;

public class Conjunto {
	
	// TP2 - 6 - Escribir los m�todos externos que implementan las operaciones intersecci�n, uni�n y diferencia
	static ConjuntoTDA interseccionConjunto(ConjuntoTDA A, ConjuntoTDA B){
		ConjuntoTDA C = new ConjuntoEstatica1();
		C.InicializarConjunto();
		int aux;
		while(!A.ConjuntoVac�o()){
			aux = A.Elegir();
			A.Sacar(aux);
			if(B.Pertenece(aux))
				C.Agregar(aux);
		}
		return C;
	}
	static ConjuntoTDA unionConjunto(ConjuntoTDA A, ConjuntoTDA B){
		ConjuntoTDA C = new ConjuntoEstatica1();
		C.InicializarConjunto();
		int aux;
		while(!A.ConjuntoVac�o()){
			aux = A.Elegir();
			A.Sacar(aux);
			C.Agregar(aux);
		}
		while(!B.ConjuntoVac�o()){
			aux = B.Elegir();
			B.Sacar(aux);
			C.Agregar(aux);
		}
		return C;
	}
	static ConjuntoTDA diferenciaConjunto(ConjuntoTDA A, ConjuntoTDA B){
		int aux;
		while(!B.ConjuntoVac�o()){
			aux = B.Elegir();
			B.Sacar(aux);
			if(A.Pertenece(aux))
				A.Sacar(aux);
		}
		return A;
	}
	
	/* TP3 - 3.a - Calcular la diferencia sim�trica entre dos conjuntos A y B (definido en clase)
	Sin utilizar las operaciones uni�n, intersecci�n y diferencia */
	static ConjuntoTDA diferenciaSimetricaA1(ConjuntoTDA A, ConjuntoTDA B){
		ConjuntoTDA C = new ConjuntoEstatica1();
		C.InicializarConjunto();
		int aux;
		while(!A.ConjuntoVac�o()){
			aux = A.Elegir();
			A.Sacar(aux);
			if(B.Pertenece(aux))
				B.Sacar(aux);
			else
				C.Agregar(aux);
		}
		while(!B.ConjuntoVac�o()){
			aux = B.Elegir();
			B.Sacar(aux);
			C.Agregar(aux);
		}
		return C;
	}
	static ConjuntoTDA diferenciaSimetricaA2(ConjuntoTDA A, ConjuntoTDA B){
		ConjuntoTDA C = new ConjuntoEstatica1();
		C.InicializarConjunto();
		int aux;
		while(!A.ConjuntoVac�o()){
			aux = A.Elegir();
			A.Sacar(aux);
			C.Agregar(aux);
		}
		while(!B.ConjuntoVac�o()){
			aux = B.Elegir();
			B.Sacar(aux);
			if(C.Pertenece(aux))
				C.Sacar(aux);
			else
				C.Agregar(aux);
		}
		return C;
	}
	
	/* TP3 - 3.a - Calcular la diferencia sim�trica entre dos conjuntos A y B (definido en clase)
	Utilizando las operaciones uni�n, intersecci�n y diferencia */
	static ConjuntoTDA diferenciaSimetricaB(ConjuntoTDA A, ConjuntoTDA B){
		return unionConjunto(diferenciaConjunto(A,B),diferenciaConjunto(B,A));
	}
	
	// TP3 - 3.d - Determinar si dos conjuntos son iguales
	static boolean conjuntosIguales(ConjuntoTDA A, ConjuntoTDA B){
		int valor = 0;  
		while(!A.ConjuntoVac�o()){
			valor = A.Elegir();
			A.Sacar(valor);
			if(!B.Pertenece(valor))
				return false;
			else
				B.Sacar(valor);
			if(A.ConjuntoVac�o()&&!B.ConjuntoVac�o() || !A.ConjuntoVac�o()&&B.ConjuntoVac�o())
				return false;
		}
		return true;
	}
	
	// TP3 - 3.e - Calcular la cardinalidad (cantidad de elementos) de un conjunto
	static int cardinalidadConjunto(ConjuntoTDA A){
		int cant = 0;
		int valor;
		while(!A.ConjuntoVac�o()){
			valor = A.Elegir();
			A.Sacar(valor);
			cant++;
		}
		return cant;
	}
	
	// TP3 - 3.f - Generar el conjunto de elementos que est�n tanto en la Pila P y en la Cola C
	static ConjuntoTDA pilaColaComun(PilaTDA P, ColaTDA C){
		ConjuntoTDA comun = new ConjuntoEstatica1();
		comun.InicializarConjunto();
		PilaTDA cmp = new PilaEstatica1();
		cmp.InicializarPila();
		PilaTDA aux = new PilaEstatica1();
		aux.InicializarPila();
		while(!C.ColaVac�a()){
			cmp.Apilar(C.Primero());
			C.Desacolar();
			while(!P.PilaVac�a() && !cmp.PilaVac�a()){
				if(P.Tope() == cmp.Tope()){
					comun.Agregar(cmp.Tope());
					cmp.Desapilar();
					P.Desapilar();
				}else{
					aux.Apilar(P.Tope());
					P.Desapilar();
				}
			}
			if(!cmp.PilaVac�a())
				cmp.Desapilar();
			while(!aux.PilaVac�a()){
				C.Acolar(aux.Tope());
				aux.Desapilar();
			}
		}
		return comun;
	}
	
	/* TP3 - 3.g - Determinar si los elementos de una Pila P son los mismos que los de una Cola C. No interesa el orden ni si est�n 
	repetidos o no */
	static boolean pilaColaIgual(PilaTDA P, ColaTDA C){
		ConjuntoTDA pilaC = new ConjuntoEstatica1();
		pilaC.InicializarConjunto();
		ConjuntoTDA colaC = new ConjuntoEstatica1();
		colaC.InicializarConjunto();
		while(!P.PilaVac�a()){
			pilaC.Agregar(P.Tope());
			P.Desapilar();
		}
		while(!C.ColaVac�a()){
			colaC.Agregar(C.Primero());
			C.Desacolar();
		}
		return conjuntosIguales(pilaC, colaC);
	}
	
	// Imprimir por pantalla un conjunto
	public static void imprimirConjunto(ConjuntoTDA A){
		ConjuntoTDA aux = new ConjuntoEstatica1();
		aux.InicializarConjunto();
		int num;
		System.out.print("Conjunto: {");
		if(A.ConjuntoVac�o()){
			System.out.print("}");
			System.out.println();
		}else{	
			while(!A.ConjuntoVac�o()){
				num = A.Elegir();
				aux.Agregar(num);
				A.Sacar(num);
				if(!A.ConjuntoVac�o())
					System.out.print(num+",");
				else{
					System.out.print(num+"}");
					System.out.println();
				}
			}
			while(!aux.ConjuntoVac�o()){
				num = aux.Elegir();
				aux.Sacar(num);
				A.Agregar(num);
			}
		}
	}
	
	public static void main(String[] args) {
		// DATOS
		ConjuntoTDA A = new ConjuntoEstatica1();
		A.InicializarConjunto();
		ConjuntoTDA B = new ConjuntoEstatica1();
		B.InicializarConjunto();
		A.Agregar(10);
		A.Agregar(2);
		A.Agregar(3);
		// M�TODOS
		imprimirConjunto(A);
		imprimirConjunto(B);
	}

}
