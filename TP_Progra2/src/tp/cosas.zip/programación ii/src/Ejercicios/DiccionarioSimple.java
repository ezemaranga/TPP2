package Ejercicios;

import Implementaciones.ConjuntoEstatica1;
import Implementaciones.DiccionarioMultipleDinamica;
import Implementaciones.DiccionarioSimpleDinamica;
import Interfaces.ConjuntoTDA;
import Interfaces.DiccionarioMultipleTDA;
import Interfaces.DiccionarioSimpleTDA;

public class DiccionarioSimple {

	/* TP6 - 5.2 - Dado un Diccionario Simple D, que representa el concepto cl�sico de diccionario: la clave representa una palabra y el valor su 
	significado. Generar un Diccionario M�ltiple DS que a partir de un significado s, vincule todas las palabras que tienen dicho significado,
	es decir que son sin�nimos. Cada clave s ser� un significado y los valores asociados (sin�nimos) aquellas claves de D que ten�an asociado 
	el valor s */
	static DiccionarioMultipleTDA significadoDS(DiccionarioSimpleTDA D){
		DiccionarioMultipleTDA DS = new DiccionarioMultipleDinamica();
		DS.InicializarDiccionario();
		ConjuntoTDA claves = D.Claves();
		int valor, clave;
		while(!claves.ConjuntoVac�o()){
			clave = claves.Elegir();
			claves.Sacar(clave);
			valor = D.Recuperar(clave);
			DS.Agregar(valor, clave);
		}
		return DS;
	}
	
	// Mostrar por pantalla un Diccionario Simple
	public static void imprimirDS(DiccionarioSimpleTDA DS){
		System.out.println("DICCIONARIO SIMPLE (Clave - Valor)");
		ConjuntoTDA C = new ConjuntoEstatica1();
		C = DS.Claves();
		if(!C.ConjuntoVac�o()){
		int auxC, auxV;
			while(!C.ConjuntoVac�o()){
				auxC = C.Elegir();
				auxV = DS.Recuperar(auxC);
				System.out.println(auxC+" - "+auxV);
				C.Sacar(auxC);
			}
		}else{
			System.out.println("(Vac�o)");
		}
	}
	
	public static void main(String[] args) {
		// DATOS
		DiccionarioSimpleTDA D = new DiccionarioSimpleDinamica();
		D.InicializarDiccionario();
		D.Agregar(2, 1);
		D.Agregar(3, 1);
		D.Agregar(5, 1);
		D.Agregar(1, 8);
		D.Agregar(7, 8);
		// M�TODOS
		DiccionarioMultiple.imprimirDM(significadoDS(D));
	}

}
