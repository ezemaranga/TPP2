package Ejercicios;

import Interfaces.ColaPrioridadTDA;
import Interfaces.ConjuntoTDA;
import Interfaces.DiccionarioMultipleTDA;
import Implementaciones.ColaPrioridadEstatica1;
import Implementaciones.ConjuntoEstatica1;
import Implementaciones.DiccionarioMultipleEstatica;


public class ColaPrioridad {

	// TP1 - 6.a - Combinar dos colas con prioridades CP1 y CP2, generando una nueva cola con prioridades. Considerar que a igual prioridad, los elementos de la CP1 son m�s prioritarios que los de la CP2.
	static ColaPrioridadTDA combinarColaPrioridad(ColaPrioridadTDA A, ColaPrioridadTDA B){
		ColaPrioridadTDA comb = new ColaPrioridadEstatica1();
		comb.InicializarCola();
		while(!A.ColaVac�a()){
			comb.AcolarPrioridad(A.Primero(), A.Prioridad());
			A.Desacolar();
		}
		while(!B.ColaVac�a()){
			comb.AcolarPrioridad(B.Primero(), B.Prioridad());
			B.Desacolar();
		}
		return comb;
	}
	
	// TP1 - 6.b - Determinar si dos Colas con prioridad son id�nticas.
	static boolean colaPrioridadIdentica(ColaPrioridadTDA A, ColaPrioridadTDA B){
		while(!A.ColaVac�a() && !B.ColaVac�a()){
			if(A.Primero()!=B.Primero() || A.Prioridad()!=B.Prioridad())
				return false;
			else{
				A.Desacolar();
				B.Desacolar();
			}
			if(!A.ColaVac�a()&&B.ColaVac�a() || A.ColaVac�a()&&!B.ColaVac�a())
				return false;
		}
		if(!A.ColaVac�a()&&B.ColaVac�a() || A.ColaVac�a()&&!B.ColaVac�a())
			return false;
		else
			return true;
	}
	
	/* TP3 - 4a - Escribir un m�todo externo que permita generar un Diccionario M�ltiple que permita, para cada valor presente en la 
	ColaPrioridad C recuperar todas las	prioridades que tiene asociadas en C */
	static DiccionarioMultipleTDA generarDMprioridades(ColaPrioridadTDA C){
		DiccionarioMultipleTDA DM = new DiccionarioMultipleEstatica();
		DM.InicializarDiccionario();
		int clave, prioridad;
		while(!C.ColaVac�a()){
			clave = C.Primero();
			prioridad = C.Prioridad();
			C.Desacolar();
			DM.Agregar(clave, prioridad);
		}
		return DM;
	}
	
	// Imprimir por pantalla una cola con prioridad
	public static void imprimirColaPrioridad(ColaPrioridadTDA A){
		ColaPrioridadTDA aux = new ColaPrioridadEstatica1();
		aux.InicializarCola();
		System.out.println("Cola Prioridad:");
		while(!A.ColaVac�a()){
			aux.AcolarPrioridad(A.Primero(), A.Prioridad());
			System.out.print(A.Primero()+"("+A.Prioridad()+") ");
			A.Desacolar();
		}
		while(!aux.ColaVac�a()){
			A.AcolarPrioridad(aux.Primero(), aux.Prioridad());
			aux.Desacolar();
		}
		System.out.println();
	}
			
	public static void main(String[] args) {
		// DATOS
		ColaPrioridadTDA A = new ColaPrioridadEstatica1();
		A.InicializarCola();
		A.AcolarPrioridad(0, 1);
		A.AcolarPrioridad(0, 2);
		A.AcolarPrioridad(1, 2);
		A.AcolarPrioridad(3, 4);
		// EJERCICIOS
		
	}

}
