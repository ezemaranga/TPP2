package Interfaces;

public interface ColaPrioridadTDA {
	void InicializarCola(); // PC: -
	boolean ColaVac�a(); //PC: Cola Inicializada
	int Primero(); // PC: Cola Inicializada y No Vac�a
	void AcolarPrioridad(int x, int prioridad); // PC: Cola Inicializada
	void Desacolar(); // PC: Cola Inicializada y No Vac�a
	int Prioridad(); // PC: Cola Inicializada y No Vac�a
}