package Interfaces;

public interface GrafoTDA {
	void InicializarGrafo();
	void AgregarVertice(int v); // PC: Grafo Inicializado y V�rtice No Existente
	void EliminarVertice( int v); // PC: Grafo Inicializado y V�rtice Existente
	ConjuntoTDA Vertices(); // PC: Grafo Inicializado
	void AgregarArista( int v1 , int v2 , int peso ); // PC: Grafo Inicializado, Arista No Existente y V�rtices Existentes
	void EliminarArista( int v1 , int v2); // PC: Grafo Inicializado y Arista Existente
	boolean ExisteArista( int v1 , int v2); // PC: Grafo Inicializado y Nodos Existentes
	int PesoArista( int v1 , int v2); // PC: Grafo Inicializado y Arista Existente
}