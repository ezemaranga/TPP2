package Interfaces;

public interface PilaTDA {
	void InicializarPila(); // PC: -
	boolean PilaVac�a(); //PC: Pila Inicializada
	int Tope(); // PC: Pila Inicializada y No Vac�a
	void Apilar(int x); // PC: Pila Inicializada
	void Desapilar(); // PC: Pila Inicializada y No Vac�a
}