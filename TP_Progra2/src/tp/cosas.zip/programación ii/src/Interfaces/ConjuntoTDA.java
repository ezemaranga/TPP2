package Interfaces;

public interface ConjuntoTDA {
	void InicializarConjunto(); // PC: -
	boolean ConjuntoVac�o(); // PC: Conjunto Inicializado
	void Agregar(int e); // PC: Conjunto Inicializado
	int Elegir(); // PC: Conjunto Inicializado y No Vac�o
	void Sacar(int e); // PC: Conjunto Inicializado
	boolean Pertenece(int e); // PC: Conjunto Inicializado
}
