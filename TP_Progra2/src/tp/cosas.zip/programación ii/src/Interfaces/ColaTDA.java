package Interfaces;

public interface ColaTDA {
	void InicializarCola(); // PC: -
	boolean ColaVac�a(); //PC: Cola Inicializada
	int Primero(); // PC:Cola Inicializada y No Vac�a
	void Acolar(int x); // PC: Cola Inicializada
	void Desacolar(); // PC: Cola Inicializada y No Vac�a
}
