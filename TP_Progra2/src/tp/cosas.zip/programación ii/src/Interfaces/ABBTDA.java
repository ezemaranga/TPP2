package Interfaces;

public interface ABBTDA {
	void InicializarABB(); // PC
	boolean ABBVac�o(); // PC:
	void AgregarElem(int x); // PC:
	void EliminarElem(int x); // PC:
	int Ra�z(); // PC:
	ABBTDA HijoIzq(); // PC:
	ABBTDA HijoDer(); // PC:
}
