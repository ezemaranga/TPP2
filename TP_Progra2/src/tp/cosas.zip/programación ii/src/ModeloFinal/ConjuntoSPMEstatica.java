package ModeloFinal;

import ModeloFinal.ConjuntoSPM;

public class ConjuntoSPMEstatica implements ConjuntoSPM {
	// DATOS
	int [] elementos;
	int cant;
	final int MAX = 100;
	// M�TODOS
	public void InicializarConjunto() { // Costos: Constante (Temporal) - Constante (Espacial)
		elementos = new int[MAX];
		cant=0;
	}
	public boolean ConjuntoVac�o() { // Costos: Constante (Temporal) - Cero (Espacial)
		return cant==0;
	}
	public void Agregar(int e){ // Costos: Lineal (Temporal) - Constante (Espacial)
		if (!this.Pertenece(e)){
			int i=0;
			while(i<cant && e>elementos[i])
				i++;
			if(i==cant){
				elementos[cant] = e;
				cant++;
			}
		}
	}
	public int Elegir() { // Costos: Constante (Temporal) - Cero (Espacial)
		return elementos[cant];
	}
	public void Sacar(int e) { // Costos: Lineal (Temporal) - Constante (Espacial)
		int i=0;
		while(i<cant && elementos[i]!=e)
			i++;
		if(i<cant){ // Lo encontro
			elementos[i] = elementos[cant-1];
			cant--;
		}
	}
	public boolean Pertenece(int e) { // Costos: Lineal (Temporal) - Constante (Espacial)
		int i=0;
		while(i<cant && elementos[i]!=e)
			i++;
		return i<cant;
	}

}
