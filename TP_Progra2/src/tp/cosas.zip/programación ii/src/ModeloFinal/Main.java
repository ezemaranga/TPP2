package ModeloFinal;

import Implementaciones.ABBDinamica;
import Implementaciones.ConjuntoEstatica1;
import Implementaciones.DiccionarioMultipleEstatica;
import Implementaciones.PilaEstatica1;
import Interfaces.ABBTDA;
import Interfaces.ConjuntoTDA;
import Interfaces.DiccionarioMultipleTDA;
import Interfaces.GrafoTDA;
import Interfaces.PilaTDA;
import ModeloFinal.ConjuntoSPM;
import ModeloFinal.ConjuntoSPMEstatica;
import Recursos.ABBGraph;


public class Main {

	/* 4.a - Escribir los m�todos externos que permitan: Dada una Pila P, armar un conjunto C con aquellos valores que aparecen mas de
	una vez en P */
	static ConjuntoTDA conjuntoRepetidosPila(PilaTDA P){
		ConjuntoTDA C = new ConjuntoEstatica1();
		C.InicializarConjunto();
		PilaTDA aux = new PilaEstatica1();
		aux.InicializarPila();
		int valor;
		while(!P.PilaVac�a()){
			valor = P.Tope();
			P.Desapilar();
			while(!P.PilaVac�a()){
				if(P.Tope()==valor){
					C.Agregar(valor);
					P.Desapilar();
				}else{
					aux.Apilar(P.Tope());
					P.Desapilar();
				}
			}
			while(!aux.PilaVac�a()){
				P.Apilar(aux.Tope());
				aux.Desapilar();
			}
		}
		return C;
	}
	
	/* 4.b - Dado un DiccionarioMultiple D, calcular el conjunto de los valores que aparecen vinculados a mas de una clave */
	static ConjuntoTDA valoresRepetidos(DiccionarioMultipleTDA DM){
		ConjuntoTDA claves = DM.Claves();
		ConjuntoTDA valores = new ConjuntoEstatica1();
		valores.InicializarConjunto();
		ConjuntoTDA valores2 = new ConjuntoEstatica1();
		valores2.InicializarConjunto();
		ConjuntoTDA valoresRep = new ConjuntoEstatica1();
		valoresRep.InicializarConjunto();
		int clave, valor;
		while(!claves.ConjuntoVac�o()){
			clave = claves.Elegir();
			claves.Sacar(clave);
			valores = DM.Recuperar(clave);
			while(!valores.ConjuntoVac�o()){
				valor = valores.Elegir();
				valores.Sacar(valor);
				if(valores2.Pertenece(valor)){
					valoresRep.Agregar(valor);
				}
				else
					valores2.Agregar(valor);
			}
		}
		
		return valoresRep;
	}
	
	/* 5 - Determinar si un ABB es completo. Se dice que un ABB es completo si todos sus nodos cumplen con que la cantidad de elementos de su 
	hijo izquierdo es igual a la cantidad de elementos de su hijo derecho */
	static boolean ABBCompleto(ABBTDA A){
		if(A.ABBVac�o()){
			return true;
		}else if(!A.HijoIzq().ABBVac�o() && !A.HijoDer().ABBVac�o() && cantidadElem(A.HijoDer())==cantidadElem(A.HijoIzq()))
			return true;
			else 
				return false;
	}
	static int cantidadElem(ABBTDA A){
		if(A.ABBVac�o()){
			return 0;
		}else{
			return 1 + cantidadElem(A.HijoIzq()) + cantidadElem(A.HijoDer());
		}
	}
	
	/* 6 - Dado un ABB A y un elemento e que se encuentra en A, determinar la suma de los valores desde la ra�z hasta e (ambos inclusive) */
	static int valoresCamino(ABBTDA A, int e){
		if(A.ABBVac�o())
			return 0;
		else{
			if(A.Ra�z() == e)
				return A.Ra�z();
			else if (A.Ra�z()>e)
				return A.Ra�z() + valoresCamino(A.HijoIzq(),e);
			else
				return A.Ra�z() + valoresCamino(A.HijoDer(),e);
		}
	}
	
	/* 9 - Dado un grafo G, determinar cual es el n�mero de conexiones del v�rtice mas conectado (contando aristas entrantes y aristas salientes)
	 con el resto de los v�rtices. */
	static int VerticeConectado(GrafoTDA G){
		ConjuntoTDA Vertice = G.Vertices();
		ConjuntoTDA Vertice2 = G.Vertices();
		int mayor=0, con=0, v, v2;
		while (!Vertice.ConjuntoVac�o()){
			v = Vertice.Elegir();
			Vertice.Sacar(v);
			Vertice2 = G.Vertices();
			con=0;
			while(!Vertice2.ConjuntoVac�o()){
				v2= Vertice2.Elegir();
				Vertice2.Sacar(v2);
				if(G.ExisteArista(v,v2))
					con++;
				if(v!=v2){
				if(G.ExisteArista(v2, v))
					con++;
				}
			}
			if(mayor<con)
				mayor=con;
		}
		return mayor;
	}
	
	// Imprimir por pantalla un conjunto
		public static void imprimirConjunto(ConjuntoTDA A){
			ConjuntoTDA aux = new ConjuntoEstatica1();
			aux.InicializarConjunto();
			int num;
			System.out.print("Conjunto: {");
			if(A.ConjuntoVac�o()){
				System.out.print("}");
				System.out.println();
			}else{	
				while(!A.ConjuntoVac�o()){
					num = A.Elegir();
					aux.Agregar(num);
					A.Sacar(num);
					if(!A.ConjuntoVac�o())
						System.out.print(num+",");
					else{
						System.out.print(num+"}");
						System.out.println();
					}
				}
				while(!aux.ConjuntoVac�o()){
					num = aux.Elegir();
					aux.Sacar(num);
					A.Agregar(num);
				}
			}
		}
	
	// Imprimir por pantalla un conjunto
	public static void imprimirConjuntoSPM(ConjuntoSPM A){
		ConjuntoTDA aux = new ConjuntoEstatica1();
		aux.InicializarConjunto();
		int num;
		System.out.print("Conjunto: {");
		if(A.ConjuntoVac�o()){
			System.out.print("}");
			System.out.println();
		}else{	
			while(!A.ConjuntoVac�o()){
				num = A.Elegir();
				aux.Agregar(num);
				A.Sacar(num);
				if(!A.ConjuntoVac�o())
					System.out.print(num+",");
				else{
					System.out.print(num+"}");
					System.out.println();
				}
			}
			while(!aux.ConjuntoVac�o()){
				num = aux.Elegir();
				aux.Sacar(num);
				A.Agregar(num);
			}
		}
	}
	
	public static void main(String[] args) {
		
	}

}
