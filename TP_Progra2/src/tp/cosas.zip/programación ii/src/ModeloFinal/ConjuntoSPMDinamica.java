package ModeloFinal;

public class ConjuntoSPMDinamica implements ConjuntoSPM {
	// DATOS
	class nodo{
		int valor;
		nodo sig;
	}
	nodo p;
	// M�TODOS
	public void InicializarConjunto() { // Costos: Constante (Temporal) - Cero (Espacial)
		p=null;
	}
	public boolean ConjuntoVac�o() { // Costos: Constante (Temporal) - Cero (Espacial)
		return p==null;
	}
	public void Agregar(int e) { // Costos: Lineal (Temporal) - Constante (Espacial)
		if(!this.Pertenece(e)){
			nodo aux = p;
			while(aux!=null && aux.valor<e)
				aux = aux.sig;
			if(aux==null){ // Recorrio todo: Son todos menores
				nodo nuevo = new nodo();
				nuevo.valor = e;
				nuevo.sig = p;
				p = nuevo;	
			}	
		}
	}
	public int Elegir() { // Costos: Constante (Temporal) - Cero (Espacial)
		return p.valor;
	}
	public void Sacar(int e) { // Costos: Lineal (Temporal) - Constante (Espacial)
		nodo aux=p;
		while(aux.valor!=e && aux!=null)
			aux=aux.sig;
		if(aux!=null){
			aux.valor=p.valor;
			p = p.sig;
		}
	}
	public boolean Pertenece(int e) { // Costos: Lineal (Temporal) - Constante (Espacial)
		nodo aux = p;
		while(aux!=null && e!=aux.valor)
			aux = aux.sig;
		return aux!=null;
	}
}
