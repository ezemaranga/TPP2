package MetExt;

import Implementaciones.ConjuntoLD;
import Implementaciones.DiccionarioSimple;
import Interfaces.ConjuntoTDA;
import Interfaces.DiccionarioMultipleTDA;
import Interfaces.DiccionarioSimpleTDA;

public class MetExtTPO {

	// Mostrar por pantalla un Diccionario Simple
	public static void MostrarDS(DiccionarioSimpleTDA DS){
		System.out.println("DICCIONARIO SIMPLE (Clave - Valor)");
		ConjuntoTDA C = new ConjuntoLD();
		C = DS.Claves();
		if(!C.ConjuntoVacio()){
		int auxC, auxV;
			while(!C.ConjuntoVacio()){
				auxC = C.Elegir();
				auxV = DS.Recuperar(auxC);
				System.out.println(auxC+" - "+auxV);
				C.Sacar(auxC);
			}
		}else{
			System.out.println("(Vac�o)");
		}
	}

	// Mostrar por pantalla un Conjunto
	public static void MostrarConjunto(ConjuntoTDA C){
		System.out.println("CONJUNTO");
		if(!C.ConjuntoVacio()){
			int aux;
			while(!C.ConjuntoVacio()){
				aux = C.Elegir();
				C.Sacar(aux);
				if(!C.ConjuntoVacio())
					System.out.print(aux+",");
				else
					System.out.print(aux);
			}
			System.out.println();
		}else
			System.out.println("(Vac�o)");
	}

	// Mostrar por pantalla un Diccionario Multiple
	public static void MostrarDM(DiccionarioMultipleTDA DM){
		System.out.println("DICCIONARIO M�LTIPLE (Clave - Valores)");
		ConjuntoTDA C = new ConjuntoLD();
		C.InicializarConjunto();
		C = DM.Claves();
		if(!C.ConjuntoVacio()){
			int auxC, auxV;
			ConjuntoTDA V = new ConjuntoLD();
			V.InicializarConjunto();
			while(!C.ConjuntoVacio()){
				auxC = C.Elegir(); // Saco la clave
				V = DM.Recuperar(auxC); // Saco todos los valores (m�nimo uno)
				System.out.print(auxC+" - {");
				while(!V.ConjuntoVacio()){
					auxV = V.Elegir();
					V.Sacar(auxV);
					if(!V.ConjuntoVacio())
						System.out.print(auxV+",");
					else
						System.out.print(auxV+"}");
				}
				System.out.println();
				C.Sacar(auxC);
			}
		}else{
			System.out.println("(Vac�o)");
		}
	}
	
	// Armar un Diccionario Simple donde cada clave de DM tiene asociada la cardinalidad del conjunto de sus valores,
	public static DiccionarioSimpleTDA DSCardConjVal(DiccionarioMultipleTDA DM){
		DiccionarioSimpleTDA D = new DiccionarioSimple();
		D.InicializarDiccionario();
		ConjuntoTDA C = new ConjuntoLD();
		C.InicializarConjunto();
		C = DM.Claves();
		if(!C.ConjuntoVacio()){
			ConjuntoTDA V = new ConjuntoLD();
			V.InicializarConjunto();
			int cant, clave, valor;
			while(!C.ConjuntoVacio()){
				cant=0;
				clave = C.Elegir();
				C.Sacar(clave);
				V = DM.Recuperar(clave);
				while(!V.ConjuntoVacio()){
					valor = V.Elegir();
					V.Sacar(valor);
					cant++;
				}
				D.Agregar(clave, cant);				
			}
			return D;
		}else
			return D;
	}
	
	// Armar un Diccionario Simple donde cada valor presente en DM tiene asociada la cantidad de veces que aparece en DM,
	public static DiccionarioSimpleTDA DSCantVal(DiccionarioMultipleTDA DM){
		DiccionarioSimpleTDA D = new DiccionarioSimple();
		D.InicializarDiccionario();
		ConjuntoTDA clavesDM = new ConjuntoLD();
		clavesDM.InicializarConjunto();
		clavesDM = DM.Claves();
		if(!clavesDM.ConjuntoVacio()){
			int claveDM, valorDM, valorDS;
			ConjuntoTDA valoresDMaux = new ConjuntoLD();
			valoresDMaux.InicializarConjunto();
			ConjuntoTDA clavesDS = new ConjuntoLD();
			clavesDS.InicializarConjunto();
			while(!clavesDM.ConjuntoVacio()){ // Mientras haya claves en diccionario multiple
				// Saco claveDM y cargo en valoresDMaux los valores asociados
				claveDM = clavesDM.Elegir();
				clavesDM.Sacar(claveDM);
				valoresDMaux = DM.Recuperar(claveDM);
				clavesDS = D.Claves();
				while(!valoresDMaux.ConjuntoVacio())// Mientras haya valores asociados
				{
					valorDM = valoresDMaux.Elegir();
					valoresDMaux.Sacar(valorDM);
					if(!clavesDS.Pertenece(valorDM)){ // Si valorDM NO pertenece -> Creo entrada diccionario con valor=1
						D.Agregar(valorDM,1);
					}else{ // Si valorDM pertenece -> Recupero valor y sumo uno
						// Recuperar valorDS
						valorDS = D.Recuperar(valorDM);
						valorDS++;
						D.Agregar(valorDM, valorDS);
					}
				}
			}
			return D;
		}else
			return D;
	}
	
	// Determinar el conjunto de los valores que no se repiten en el diccionario.
	public static ConjuntoTDA ValoresNoRepetidos(DiccionarioMultipleTDA DM){
		ConjuntoTDA C = new ConjuntoLD();
		C.InicializarConjunto();
		ConjuntoTDA clavesDM = new ConjuntoLD();
		clavesDM.InicializarConjunto();
		clavesDM = DM.Claves();
		ConjuntoTDA valoresDMaux = new ConjuntoLD();
		valoresDMaux.InicializarConjunto();
		ConjuntoTDA repetidos = new ConjuntoLD();
		repetidos.InicializarConjunto();
		int claveDM, cargar;
		while(!clavesDM.ConjuntoVacio()){
			claveDM = clavesDM.Elegir();
			clavesDM.Sacar(claveDM);
			valoresDMaux = DM.Recuperar(claveDM);
			while(!valoresDMaux.ConjuntoVacio()){
				cargar = valoresDMaux.Elegir();
				valoresDMaux.Sacar(cargar);
				if (!repetidos.Pertenece(cargar)){	
					if(!C.Pertenece(cargar)) // NO pertenece ni a C ni a repetidos
						C.Agregar(cargar);
					else{ // Pertenece a C pero no a repetidos
						C.Sacar(cargar);
						repetidos.Agregar(cargar);
					}
				}
			}
		}
		return C;
	}
	
	public static void CargarDiccSimple(DiccionarioSimpleTDA DS){
		DS.Agregar(8, 2);
		DS.Agregar(1, 3);
		DS.Agregar(14, 7);
		DS.Agregar(13, 17);
		DS.Agregar(3, 2);
	}	
	
	public static void CargarDiccMult(DiccionarioMultipleTDA DM){
		DM.Agregar(8, 2);
		DM.Agregar(8, 9);
		DM.Agregar(8, 1);
		DM.Agregar(8, 3);
		DM.Agregar(1, 3);
		DM.Agregar(1, 4);
		DM.Agregar(14, 7);
		DM.Agregar(14, 9);
		DM.Agregar(13, 17);
		DM.Agregar(3, 2);
		DM.Agregar(3, 8);
		DM.Agregar(8, 2);
		DM.Agregar(3, 4);
		DM.Agregar(3, 5);
		DM.EliminarValor(13, 17);
	}
	
}
