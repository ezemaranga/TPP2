package Principal;

import Implementaciones.ConjuntoLD;
import Implementaciones.DiccionarioMultipleBool;
import Implementaciones.DiccionarioSimple;
import Interfaces.ConjuntoTDA;
import Interfaces.DiccionarioMultipleTDA;
import Interfaces.DiccionarioSimpleTDA;
import MetExt.MetExtTPO;

public class Main {

	public static void main(String[] args) {

		/*DiccionarioSimpleTDA DS = new DiccionarioSimple();
		DS.InicializarDiccionario();
		MetExtTPO.CargarDiccSimple(DS);
		MetExtTPO.MostrarDS(DS);*/
		
		/*DiccionarioMultipleTDA DM = new DiccionarioMultipleBool();
		DM.InicializarDiccionario();
		MetExtTPO.CargarDiccMult(DM);
		MetExtTPO.MostrarDM(DM);*/
		
		/*//Armar un Diccionario Simple donde cada clave de DM tiene asociada la cardinalidad del conjunto de sus valores,
		DiccionarioSimpleTDA DS = MetExtTPO.DSCardConjVal(DM);
		MetExtTPO.MostrarDS(DS);
		
		//Armar un Diccionario Simple donde cada valor presente en DM tiene asociada la cantidad de veces que aparece en DM,
		DiccionarioSimpleTDA DS2 = MetExtTPO.DSCantVal(DM);
		MetExtTPO.MostrarDS(DS2);
		
		//Determinar el conjunto de los valores que no se repiten en el diccionario.
		ConjuntoTDA C = MetExtTPO.ValoresNoRepetidos(DM);
		MetExtTPO.MostrarConjunto(C);*/
	
	}

}
