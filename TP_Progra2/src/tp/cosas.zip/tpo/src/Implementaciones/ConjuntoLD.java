package Implementaciones;

import Interfaces.ConjuntoTDA;

public class ConjuntoLD implements ConjuntoTDA {
	// DATOS
	class nodo{
		int Info;
		nodo Sig;
	}
	nodo C;
	// M�TODOS
	public void InicializarConjunto() {
		C=null;
	}
	public boolean ConjuntoVacio() {
		return C==null;
	}
	public void Agregar(int x) {
		if(!this.Pertenece(x)){
			nodo Nuevo = new nodo();
			Nuevo.Info = x;
			Nuevo.Sig = C;
			C = Nuevo;
		}
	}
	public int Elegir() {
		return C.Info;
	}
	public void Sacar(int x) {
		nodo Aux = C;
		while(Aux!=null && Aux.Info!=x)
			Aux = Aux.Sig;
		if(Aux!=null){
			Aux.Info = C.Info;
			C = C.Sig;
		}
	}
	public boolean Pertenece(int x) {
		nodo Aux = C;
		while(Aux!=null && Aux.Info!=x)
			Aux = Aux.Sig;
		return Aux!=null;
	}
}
