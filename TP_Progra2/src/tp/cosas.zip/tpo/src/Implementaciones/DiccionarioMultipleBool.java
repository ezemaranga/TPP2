package Implementaciones;

import Interfaces.ConjuntoTDA;
import Interfaces.DiccionarioMultipleTDA;

public class DiccionarioMultipleBool implements DiccionarioMultipleTDA {
	//DATOS
	class Elemento{
		int clave;
		boolean[] arregloValores;
	}
	Elemento[] elementos;
	int cantClaves;
	//METODOS
	public void InicializarDiccionario(){
		elementos = new Elemento[100]; //Al inicializar el arreglo booleano se inicializa todo en FALSE
		cantClaves = 0;
	}
	public void Agregar(int clave, int valor){
		int posicionClave = buscarClave(clave);
		if (posicionClave == -1){
			posicionClave = cantClaves;
			elementos[posicionClave] = new Elemento();
			elementos[posicionClave].clave = clave;
			elementos[posicionClave].arregloValores = new boolean[100];
			cantClaves++;
		}
		Elemento e = elementos[posicionClave]; //e es un puntero a la posicion dentro del arreglo Elemento
		e.arregloValores[valor] = true;
	}
	public int buscarClave(int clave){
		int i = cantClaves-1;
		while(i>=0 && clave!=elementos[i].clave){
			i--;
		}
		return i; //Si la clave no existe devuelve -1
	}
	public void Eliminar(int clave){
		int claveEliminar = buscarClave(clave);
		if(claveEliminar != -1){
			elementos[claveEliminar] = elementos[cantClaves - 1];
			cantClaves--;
		}
	}
	public void EliminarValor(int clave, int valor){
		int clavePos = buscarClave(clave);
		int i=99;
		if(clavePos != -1){
			Elemento e = elementos[clavePos];
			e.arregloValores[valor] = false;
		}
		while (i>=0 && elementos[clavePos].arregloValores[i] != true)
			i--;
		if (i==-1)
			Eliminar (clave);
	}
	public ConjuntoTDA Recuperar(int clave){
		ConjuntoTDA c = new ConjuntoLD();
		c.InicializarConjunto();
		int posClave = buscarClave(clave);
		int i;
		if(posClave != -1){
			Elemento e = elementos[posClave];
			for (i=0; i<100; i++){
				if (e.arregloValores[i] == true)
					c.Agregar (i);
			}
		}
		return c;
	}
	public ConjuntoTDA Claves(){
		ConjuntoTDA c = new ConjuntoLD();
		c.InicializarConjunto();
		int i;
		for (i=0; i<cantClaves; i++)
			c.Agregar(elementos[i].clave);
		return c;
	}
}
